package com.cognizant.fsd.spring.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.cognizant.fsd.spring.repository.BookRepository;

public class AppMain {
	 public static void main(String args[]) {
		 AbstractApplicationContext appContext = new AnnotationConfigApplicationContext(HibernateConfig.class);
		 BookRepository bookRepository=(BookRepository) appContext.getBean("bookRepository");
		 System.out.println("bookRepository : "+bookRepository);
	 }
}
