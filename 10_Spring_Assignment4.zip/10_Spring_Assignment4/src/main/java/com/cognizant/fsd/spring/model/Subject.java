package com.cognizant.fsd.spring.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author Saugata Ray
 *
 */
@Entity
@Table(name="subject")
public class Subject implements Serializable{
	@Transient
	private static final long serialVersionId = 1L;
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	//private Long sid;
	@Column(name="SUBJECTID")
	private Long subjectId;
	@Column(name="SUBTITLE")
	private String subTitle;
	@Column(name="DURATIONINHOURS")
	private Integer durationInHours;
	@ManyToMany(fetch=FetchType.EAGER)
	private Set<Book> references=new HashSet<Book>();
	@Transient
	private List<Long> bookList;
	
	public Long getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Long subjectId) {
		this.subjectId = subjectId;
	}
	public String getSubTitle() {
		return subTitle;
	}
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}
	public Integer getDurationInHours() {
		return durationInHours;
	}
	public void setDurationInHours(Integer durationInHours) {
		this.durationInHours = durationInHours;
	}
	public Set<Book> getReferences() {
		return references;
	}
	public void setReferences(Set<Book> references) {
		this.references = references;
	}
	@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", subTitle=" + subTitle + ", durationInHours=" + durationInHours
				+ ", references=" + references + "]";
	}
	public List<Long> getBookList() {
		return bookList;
	}
	public void setBookList(List<Long> bookList) {
		this.bookList = bookList;
	}
}
