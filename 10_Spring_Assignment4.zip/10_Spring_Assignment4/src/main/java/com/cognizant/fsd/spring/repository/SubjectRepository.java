package com.cognizant.fsd.spring.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.spring.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, Long>{
	
}
