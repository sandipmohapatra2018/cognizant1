package com.cognizant.fsd.spring.global;

public class FsdConstant {
public static int GREATER_THAN_SUBJECT_DURATION=101;
public static int LESS_THAN_SUBJECT_DURATION=99;
public static int EQUAL_TO__SUBJECT_DURATION=100;
}
