package com.cognizant.fsd.spring.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.spring.model.Book;

public interface BookRepository extends CrudRepository<Book, Long>{	
	public List<Book> findByTitle(String title);
}

