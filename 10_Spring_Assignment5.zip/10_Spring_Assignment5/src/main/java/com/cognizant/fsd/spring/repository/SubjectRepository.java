package com.cognizant.fsd.spring.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.spring.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, Long>{	
	public List<Subject> findByDurationInHours(int durationInHours);
	public List<Subject> findGreaterByDurationInHours(int durationInHours);
	public List<Subject> findLessByDurationInHours(int durationInHours);	
}
