package com.cognizant.fsd.spring.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.spring.global.FsdConstant;
import com.cognizant.fsd.spring.model.Subject;
import com.cognizant.fsd.spring.repository.SubjectRepository;
@Service("subjectService")
@Transactional
public class SubjectServiceImpl implements SubjectService{
	@Autowired
	private SubjectRepository subjectRepository;

	public void setSubjectRepository(SubjectRepository subjectRepository) {
		this.subjectRepository = subjectRepository;
	}
	@Override
	public Subject addSubject(Subject subject) {
		return subjectRepository.save(subject);
	}
	@Override
	public boolean deleteSubject(long subjectId) {
		subjectRepository.delete(subjectId);
		return true;
	}
	@Override
	public Subject searchSubject(long subjectId) {	
		return subjectRepository.findOne(subjectId);
	}
	@Override
	public List<Subject> fetchAllSubject() {		
		return (List<Subject>) subjectRepository.findAll();
	}
	@Override
	public List<Subject> findByDurationInHours(int durationInHours,int subjectDurationSearchType) {		
		List<Subject> subjectList=subjectDurationSearchType==FsdConstant.EQUAL_TO__SUBJECT_DURATION?subjectRepository.findByDurationInHours(durationInHours)
				:subjectDurationSearchType==FsdConstant.GREATER_THAN_SUBJECT_DURATION?subjectRepository.findGreaterByDurationInHours(durationInHours)
				:subjectDurationSearchType==FsdConstant.LESS_THAN_SUBJECT_DURATION?subjectRepository.findLessByDurationInHours(durationInHours)
				:Collections.<Subject>emptyList();
		return subjectList;
	}

}

