package com.cognizant.fsd.spring.config;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.cognizant.fsd.spring.model.Book;
import com.cognizant.fsd.spring.model.Subject;
import com.cognizant.fsd.spring.model.UserRole;

public class AppMain {
	 public static void main(String args[]) {
	        AbstractApplicationContext context = new AnnotationConfigApplicationContext(HibernateConfig.class);
	        SessionFactory sessionFactory=(SessionFactory) context.getBean("sessionFactory");
UserRole r1 = new UserRole();
r1.setRoleId(201);
r1.setRoleName("LIBRARIAN");
UserRole r2 = new UserRole();
r2.setRoleId(202);
r2.setRoleName("PRINCIPAL");	        
	        

Session session=sessionFactory.openSession();
session.beginTransaction();
session.save(r1);
session.save(r2);
session.getTransaction().commit();
	        /*	        Subject subject=new Subject();
	       
	        Book b1=(Book) sessionFactory.openSession().get(Book.class, 101l);
	        Book b2=(Book) sessionFactory.openSession().get(Book.class, 102l);
	        System.out.println(b1 + " --- "+b2);
	        
	        Set<Book> set=new HashSet<Book>();
	        set.add(b1);
	        set.add(b2);
	        subject.setSubjectId(203l);
	        subject.setSubTitle("subTitle3");
	        subject.setDurationInHours(2);
	        subject.setReferences(set);
	        
	        Session session=sessionFactory.openSession();
	        session.beginTransaction();
	        session.save(subject);
	        session.getTransaction().commit();
	        System.out.println(context.getBean("sessionFactory"));*/
	 }
}
