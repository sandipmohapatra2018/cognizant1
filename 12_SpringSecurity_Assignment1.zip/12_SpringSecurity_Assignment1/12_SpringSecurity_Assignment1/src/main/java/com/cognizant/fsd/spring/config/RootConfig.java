package com.cognizant.fsd.spring.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.User;

import com.cognizant.fsd.spring.datastream.BinaryBookStreamCRUD;
import com.cognizant.fsd.spring.datastream.BinarySubjectStreamCRUD;
import com.cognizant.fsd.spring.service.UserService;

@Configuration
public class RootConfig implements InitializingBean{

	@Bean
	BinarySubjectStreamCRUD binarySubjectStreamCRUD() {
		return new BinarySubjectStreamCRUD();
	}
	@Bean
	BinaryBookStreamCRUD binaryBookStreamCRUD() {
		return new BinaryBookStreamCRUD();
	}
	@Override
	public void afterPropertiesSet() throws Exception {

	}


}
