package com.cognizant.fsd.spring.controller;

public class Answer {
	private String ans;

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}
}
