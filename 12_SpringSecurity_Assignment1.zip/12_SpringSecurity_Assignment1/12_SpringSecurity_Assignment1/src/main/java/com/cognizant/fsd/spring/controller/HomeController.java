package com.cognizant.fsd.spring.controller;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.fsd.spring.model.Book;
import com.cognizant.fsd.spring.model.CustomUser;
import com.cognizant.fsd.spring.model.Subject;
import com.cognizant.fsd.spring.model.UserRole;
import com.cognizant.fsd.spring.service.BookService;
import com.cognizant.fsd.spring.service.SubjectService;
import com.cognizant.fsd.spring.service.UserService;

@Controller
public class HomeController {
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private BookService bookService;
	@Autowired
	private UserService userService;
	@InitBinder
	public void dataBinding(WebDataBinder binder) {		
		FsdCollectionEditor fsdCollectionEditor = new FsdCollectionEditor(Set.class, true);
		fsdCollectionEditor.setBookService(bookService);
		//binder.registerCustomEditor(Set.class, "references", fsdCollectionEditor);
	}
	@RequestMapping(path = { "/" }, method = RequestMethod.GET)
	public String index(Model model) {
		setUserName(model);
		return "index";
	}	
	
	@RequestMapping(path = { "/login" }, method = RequestMethod.GET)
	public String login(Model model) {
		setUserName(model);
		return "login";
	}	
    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){    
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }	
	@RequestMapping(path = { "/registration" }, method = RequestMethod.GET)
	public String registration(Model model) {
		List<UserRole> userRoles = userService.getRoleList();
		model.addAttribute("customUser", new CustomUser());
		model.addAttribute("ROLE_LIST", userRoles);
		return "registration";
	}
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute final CustomUser customUser, Model model) {
		System.out.println("save customUser ");
		userService.addCustomUser(customUser);
		model.addAttribute("ENTITY_NAME", "User");		
		model.addAttribute("ENTITY_ID", customUser.getId());
		return "success";
	}
	@RequestMapping(value = "/principal/addSubject", method = RequestMethod.GET)
	public String addSubject(Model model) {
		System.out.println("add Subject");
		Subject subject = new Subject();
		model.addAttribute("subject", subject);
		model.addAttribute("BOOK_LIST", bookService.fetchAllBook());
		return "add-subject";
	}

	@RequestMapping(value = "/saveSubject", method = RequestMethod.POST)
	public String saveSubject(@ModelAttribute final Subject subject, Model model) {
		System.out.println("save Subject ");
		subject.getBookList().stream()
		.filter(bookId->bookId>0)
		.forEach(bookId->{			
			subject.getReferences().add(bookService.searchBook(bookId));
		});
		model.addAttribute("ENTITY_NAME", "Subject");
		subjectService.addSubject(subject);
		model.addAttribute("ENTITY_ID", subject.getSubjectId());
		return "success";
	}

	@RequestMapping(value = "/librarian/addBook", method = RequestMethod.GET)
	public String addBook(Model model) {
		System.out.println("add Book");
		model.addAttribute("book", new Book());
		return "add-book";
	}

	@RequestMapping(value = "/saveBook", method = RequestMethod.POST)
	public String saveBook(@ModelAttribute Book book, Model model) {
		System.out.println("save book " + book.getPublishDate());
		model.addAttribute("ENTITY_NAME", "Book");
		book = bookService.addBook(book);
		model.addAttribute("ENTITY_ID", book.getBookId());
		return "success";
	}

	@RequestMapping(value = "/librarian/deleteBook", method = RequestMethod.GET)
	public String deleteBook(Model model) {
		System.out.println("delete Book");
		return "delete-book";
	}

	@RequestMapping(value = "/performDeleteBook", method = RequestMethod.GET)
	public String performDeleteBook(@RequestParam("bookId") String bookId, Model model) {
		System.out.println("delete Book " + bookId);
		boolean isSuccess = bookService.deleteBook(Long.parseLong(bookId));
		model.addAttribute("ENTITY_NAME", "Book");
		model.addAttribute("ENTITY_ID", bookId);
		model.addAttribute("isSuccess", isSuccess);
		return "delete-success";
	}

	@RequestMapping(value = "/principal/deleteSubject", method = RequestMethod.GET)
	public String deleteSubject(Model model) {
		System.out.println("delete Book");
		return "delete-subject";
	}

	@RequestMapping(value = "/performDeleteSubject", method = RequestMethod.GET)
	public String performDeleteSubject(@RequestParam("subjectId") String subjectId, Model model) {
		System.out.println("delete subjectId " + subjectId);
		boolean isSuccess = subjectService.deleteSubject(Long.parseLong(subjectId));
		model.addAttribute("ENTITY_NAME", "Subject");
		model.addAttribute("isSuccess", isSuccess);
		model.addAttribute("ENTITY_ID", subjectId);
		return "delete-success";
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(Model model) {
		System.out.println("search Subject");
		return "search";
	}

	@RequestMapping(value = "/performSearch", method = RequestMethod.GET)
	public String performSearch(@RequestParam("id") String id, @RequestParam("entityName") String entityName,
			Model model) {
		System.out.println(entityName + "Perform Search" + id);
		Subject subject = null;
		Book book = null;
		String name = "";
		if (entityName.equals("subject")) {
			subject = subjectService.searchSubject(Long.parseLong(id));
			System.out.println("subject "+subject.getSubjectId());
			name = "subject";
		}
		if (entityName.equals("book")) {
			book = bookService.searchBook(Long.parseLong(id));
			name = "book";
		}
		model.addAttribute("ENTITY_NAME", name);
		model.addAttribute("book", book);
		model.addAttribute("subject", subject);
		return "result";
	}
	@RequestMapping(value = "/exit", method = RequestMethod.GET)
	public String exit(Model model) {
		System.out.println("exit");
		
		MyCommand myCommand=new MyCommand();
		model.addAttribute("myCommand", myCommand);
		return "exit";
	}
	@RequestMapping(value = "/saveMyCommand", method = RequestMethod.POST)
	public String saveMyCommand(@ModelAttribute MyCommand myCommand, Model model) {
		System.out.println("save saveMyCommand ");
		String s=myCommand.getSectionList().get(0).getQuestionList().get(0).getAnswerList().get(0).getAns();
		
		myCommand.getSectionList().get(0).getQuestionList().get(0).getAnswerList().get(0).setAns(s.concat(" from server"));
		System.out.println("save ans " +s);
		
		model.addAttribute("myCommand", myCommand);
		return "exit";
	}
	@RequestMapping(value = "/access_denied", method = RequestMethod.GET)
	public String accessDenied(Model model) {
		System.out.println("access_denied");
		return "access_denied";
	}
	public void setUserName(Model model) {
	      Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	      String name = auth.getName(); //get logged in username			
	      model.addAttribute("username", name);

	}
}
