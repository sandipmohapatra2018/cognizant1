package com.cognizant.fsd.spring.controller;

import java.util.ArrayList;
import java.util.List;

public class MyCommand {
private List<Section> sectionList=new ArrayList<Section>();

public List<Section> getSectionList() {
	return sectionList;
}

public void setSectionList(List<Section> sectionList) {
	this.sectionList = sectionList;
}

}
/*class Section{
private String name;	
private List<Question> questionList=new ArrayList<Question>();

public List<Question> getQuestionList() {
	return questionList==null?new ArrayList<Question>():questionList;
}

public void setQuestionList(List<Question> questionList) {
	this.questionList = questionList;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
}

class Question{
private List<Answer> answerList=new ArrayList<Answer>();

public List<Answer> getAnswerList() {
	return answerList==null?new ArrayList<Answer>():answerList;
}

public void setAnswerList(List<Answer> answerList) {
	this.answerList = answerList;
}
}

class Answer{
private String ans;

public String getAns() {
	return ans;
}

public void setAns(String ans) {
	this.ans = ans;
}	
}*/