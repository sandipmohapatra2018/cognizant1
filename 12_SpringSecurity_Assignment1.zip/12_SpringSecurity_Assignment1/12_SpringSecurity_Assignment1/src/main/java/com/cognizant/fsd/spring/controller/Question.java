package com.cognizant.fsd.spring.controller;

import java.util.ArrayList;
import java.util.List;

public class Question {
	private List<Answer> answerList=new ArrayList<Answer>();

	public List<Answer> getAnswerList() {
		return answerList;
	}

	public void setAnswerList(List<Answer> answerList) {
		this.answerList = answerList;
	}
}
