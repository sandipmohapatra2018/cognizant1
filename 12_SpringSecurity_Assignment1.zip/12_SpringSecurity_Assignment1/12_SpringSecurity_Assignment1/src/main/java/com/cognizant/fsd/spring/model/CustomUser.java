/**
 * 
 */
package com.cognizant.fsd.spring.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author Admin
 *
 */
@Entity
@Table(name="customUser")
public class CustomUser {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private long id;
private String firstName;
private String lastName;
private String username;
private String password;
@Transient
private List<Long> roleList;
@OneToMany(fetch=FetchType.EAGER)
private Set<UserRole> roles=new HashSet<UserRole>();


public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public Set<UserRole> getRoles() {
	return roles;
}
public void setRoles(Set<UserRole> roles) {
	this.roles = roles;
}
public List<Long> getRoleList() {
	return roleList;
}
public void setRoleList(List<Long> roleList) {
	this.roleList = roleList;
}

}
