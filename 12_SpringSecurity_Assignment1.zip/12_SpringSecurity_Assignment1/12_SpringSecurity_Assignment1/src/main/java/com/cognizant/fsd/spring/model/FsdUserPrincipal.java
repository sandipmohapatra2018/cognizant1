/**
 * 
 */
package com.cognizant.fsd.spring.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * @author Admin
 *
 */
public class FsdUserPrincipal implements UserDetails {
	private CustomUser customUser;
	
	public FsdUserPrincipal(CustomUser customUser) {
		this.customUser=customUser;
		getGrantedAuthorities();
	}
    private List<GrantedAuthority> getGrantedAuthorities(){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        customUser.getRoles().forEach(role->{
        	authorities.add(new SimpleGrantedAuthority("ROLE_"+role.getRoleName()));
        });        
        return authorities;
    }
    
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {		
		return getGrantedAuthorities();
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return customUser.getPassword();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return customUser.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	public CustomUser getCustomUser() {
		return customUser;
	}

	public void setCustomUser(CustomUser customUser) {
		this.customUser = customUser;
	}

}
