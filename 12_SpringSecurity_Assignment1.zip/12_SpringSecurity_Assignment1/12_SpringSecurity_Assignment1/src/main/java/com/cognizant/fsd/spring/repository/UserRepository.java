package com.cognizant.fsd.spring.repository;

import java.util.List;

import com.cognizant.fsd.spring.model.CustomUser;
import com.cognizant.fsd.spring.model.UserRole;

public interface UserRepository {
	public CustomUser searchUser(long userId);
	public CustomUser addCustomUser(CustomUser customUser);
	public CustomUser loadUserByUsername(String username);
	public List<UserRole> getRoleList();
	public List<CustomUser> getCustomUser();
}
