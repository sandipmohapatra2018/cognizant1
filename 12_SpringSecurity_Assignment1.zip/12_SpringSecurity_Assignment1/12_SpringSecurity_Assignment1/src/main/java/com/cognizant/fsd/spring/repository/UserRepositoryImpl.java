/**
 * 
 */
package com.cognizant.fsd.spring.repository;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import org.springframework.stereotype.Repository;

import com.cognizant.fsd.spring.model.CustomUser;
import com.cognizant.fsd.spring.model.UserRole;

/**
 * @author Admin
 *
 */
@Repository("userRepository")
public class UserRepositoryImpl extends AbstractDao implements UserRepository{

	@Override
	public CustomUser searchUser(long id) {
		CustomUser customUser=null;	
		try {
			customUser = (CustomUser) getSession().get(CustomUser.class, id);
		} catch (Exception e) {}
		return customUser;
	
	}

	@Override
	public CustomUser addCustomUser(CustomUser customUser) {
		Session session=getSession();
		Set<UserRole> roles=new HashSet<UserRole>();
		customUser.getRoleList().forEach(roleId->{
			UserRole userRole=(UserRole) session.get(UserRole.class, roleId);
			roles.add(userRole);			
		});		
		customUser.setRoles(roles);
		super.persist(customUser);
		return customUser;
	}

	@Override
	public CustomUser loadUserByUsername(String username) {
		System.out.println("ppppppppp : "+username);
		CustomUser customUser=null;	
		try {
			Criteria criteria=getSession().createCriteria(CustomUser.class);
			criteria.add(Restrictions.eq("username", username));
			customUser = (CustomUser) criteria.uniqueResult();
		} catch (Exception e) {
			System.err.println("errrrrr "+e);
		}	
		return customUser;
	}

	@Override
	public List<UserRole> getRoleList() {
		List<UserRole> userRoles=null;	
		try {
			Criteria criteria=getSession().createCriteria(UserRole.class);			
			userRoles = (List<UserRole>) criteria.list();
		} catch (Exception e) {}	
		return userRoles;
	}
	
	
	public List<CustomUser> getCustomUser() {
		List<CustomUser> customUsers=null;	
		try {
			Criteria criteria=getSession().createCriteria(CustomUser.class);			
			customUsers = (List<CustomUser>) criteria.list();
		} catch (Exception e) {}		
		return customUsers;
	}
}
