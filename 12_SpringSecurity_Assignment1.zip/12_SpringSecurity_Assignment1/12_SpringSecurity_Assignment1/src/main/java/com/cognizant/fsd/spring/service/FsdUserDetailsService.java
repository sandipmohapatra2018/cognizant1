package com.cognizant.fsd.spring.service;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.spring.model.CustomUser;
import com.cognizant.fsd.spring.model.FsdUserPrincipal;
import com.cognizant.fsd.spring.repository.UserRepository;
@Service("fsdUserDetailsService")
//@Transactional
public class FsdUserDetailsService implements UserDetailsService,InitializingBean{
	@Autowired
	@Qualifier("userService")
	private UserService userService;
	@Autowired
	private ApplicationContext applicationContext;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		FsdUserPrincipal fsdUserPrincipal=null;
		System.out.println(userService+" username:: "+username);
		CustomUser  customUser =userService.loadUserByUsername(username);
		System.out.println("username 2:: "+customUser);
		if(null!=customUser) {
			fsdUserPrincipal=new FsdUserPrincipal(customUser);
		}else {
			throw new UsernameNotFoundException("User not found by name: " + username);
		}	
		return fsdUserPrincipal;
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("fsdUserDetailsService......"+userService);
	}

}
