/**
 * 
 */
package com.cognizant.fsd.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.spring.model.CustomUser;
import com.cognizant.fsd.spring.model.UserRole;
import com.cognizant.fsd.spring.repository.UserRepository;

/**
 * @author Admin
 *
 */
@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepository;
	@Override
	public CustomUser searchUser(long userId) {		
		return userRepository.searchUser(userId);
	}

	@Override
	public CustomUser addCustomUser(CustomUser customUser) {		
		return userRepository.addCustomUser(customUser);
	}

	@Override
	public CustomUser loadUserByUsername(String username) {		
		return userRepository.loadUserByUsername(username);
	}

	@Override
	public List<UserRole> getRoleList() {		
		return userRepository.getRoleList();
	}

	@Override
	public List<CustomUser> getCustomUsers() {		
		return userRepository.getCustomUser();
	}

}
