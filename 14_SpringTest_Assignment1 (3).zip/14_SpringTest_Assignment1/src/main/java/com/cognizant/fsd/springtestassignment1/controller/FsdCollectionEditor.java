package com.cognizant.fsd.springtestassignment1.controller;

import java.util.Collection;

import org.springframework.beans.propertyeditors.CustomCollectionEditor;

import com.cognizant.fsd.springtestassignment1.model.Book;
import com.cognizant.fsd.springtestassignment1.service.BookService;

public class FsdCollectionEditor extends CustomCollectionEditor {
	
	private BookService bookService;
	
	public FsdCollectionEditor(Class<? extends Collection> collectionType, boolean nullAsEmptyCollection) {
		super(collectionType, nullAsEmptyCollection);		
	}

	protected Object convertElement(Object element) {
		System.out.println("element : "+element);
		Book book = bookService.searchBook((Long)element);
		return book;
	}

	public BookService getBookService() {
		return bookService;
	}

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}
	
}