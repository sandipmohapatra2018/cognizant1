package com.cognizant.fsd.springtestassignment1.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.fsd.springtestassignment1.model.Book;
import com.cognizant.fsd.springtestassignment1.model.Subject;
import com.cognizant.fsd.springtestassignment1.service.BookService;
import com.cognizant.fsd.springtestassignment1.service.SubjectService;

@Controller
public class HomeController {
	@Autowired
	private SubjectService subjectService;
	@Autowired
	private BookService bookService;

	@InitBinder
	public void dataBinding(WebDataBinder binder) {		
		FsdCollectionEditor fsdCollectionEditor = new FsdCollectionEditor(Set.class, true);
		fsdCollectionEditor.setBookService(bookService);
		//binder.registerCustomEditor(Set.class, "references", fsdCollectionEditor);
	}
	@RequestMapping(path = { "/" }, method = RequestMethod.GET)
	public String index(Model model) {
		return "index";
	}

	@RequestMapping(value = "/addSubject", method = RequestMethod.GET)
	public String addSubject(Model model) {
		System.out.println("add Subject");
		Subject subject = new Subject();
		model.addAttribute("subject", subject);
		model.addAttribute("BOOK_LIST", bookService.fetchAllBook());
		return "add-subject";
	}

	@RequestMapping(value = "/saveSubject", method = RequestMethod.POST)
	public String saveSubject(@ModelAttribute final Subject subject, Model model) {
		System.out.println("save Subject ");
		subject.getBookList().stream()
		.filter(bookId->bookId>0)
		.forEach(bookId->{			
			subject.getReferences().add(bookService.searchBook(bookId));
		});
		model.addAttribute("ENTITY_NAME", "Subject");
		subjectService.addSubject(subject);
		model.addAttribute("ENTITY_ID", subject.getSubjectId());
		return "success";
	}

	@RequestMapping(value = "/addBook", method = RequestMethod.GET)
	public String addBook(Model model) {
		System.out.println("add Book");
		model.addAttribute("book", new Book());
		return "add-book";
	}

	@RequestMapping(value = "/saveBook", method = RequestMethod.POST)
	public String saveBook(@ModelAttribute Book book, Model model) {
		System.out.println("save book " + book.getPublishDate());
		model.addAttribute("ENTITY_NAME", "Book");
		book = bookService.addBook(book);
		model.addAttribute("ENTITY_ID", book.getBookId());
		return "success";
	}

	@RequestMapping(value = "/deleteBook", method = RequestMethod.GET)
	public String deleteBook(Model model) {
		System.out.println("delete Book");
		return "delete-book";
	}

	@RequestMapping(value = "/performDeleteBook", method = RequestMethod.GET)
	public String performDeleteBook(@RequestParam("bookId") String bookId, Model model) {
		System.out.println("delete Book " + bookId);
		boolean isSuccess = bookService.deleteBook(Long.parseLong(bookId));
		model.addAttribute("ENTITY_NAME", "Book");
		model.addAttribute("ENTITY_ID", bookId);
		model.addAttribute("isSuccess", isSuccess);
		return "delete-success";
	}

	@RequestMapping(value = "/deleteSubject", method = RequestMethod.GET)
	public String deleteSubject(Model model) {
		System.out.println("delete Book");
		return "delete-subject";
	}

	@RequestMapping(value = "/performDeleteSubject", method = RequestMethod.GET)
	public String performDeleteSubject(@RequestParam("subjectId") String subjectId, Model model) {
		System.out.println("delete subjectId " + subjectId);
		boolean isSuccess = subjectService.deleteSubject(Long.parseLong(subjectId));
		model.addAttribute("ENTITY_NAME", "Subject");
		model.addAttribute("isSuccess", isSuccess);
		model.addAttribute("ENTITY_ID", subjectId);
		return "delete-success";
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(Model model) {
		System.out.println("search Subject");
		return "search";
	}

	@RequestMapping(value = "/performSearch", method = RequestMethod.GET)
	public String performSearch(@RequestParam("id") String id, @RequestParam("entityName") String entityName,
			Model model) {
		System.out.println(entityName + "Perform Search" + id);
		Subject subject = null;
		Book book = null;
		String name = "";
		if (entityName.equals("subject")) {
			subject = subjectService.searchSubject(Long.parseLong(id));
			System.out.println("subject "+subject.getSubjectId());
			name = "subject";
		}
		if (entityName.equals("book")) {
			book = bookService.searchBook(Long.parseLong(id));
			name = "book";
		}
		model.addAttribute("ENTITY_NAME", name);
		model.addAttribute("book", book);
		model.addAttribute("subject", subject);
		return "result";
	}
	@RequestMapping(value = "/exit", method = RequestMethod.GET)
	public String exit(Model model) {
		System.out.println("exit");
		return "exit";
	}
}
