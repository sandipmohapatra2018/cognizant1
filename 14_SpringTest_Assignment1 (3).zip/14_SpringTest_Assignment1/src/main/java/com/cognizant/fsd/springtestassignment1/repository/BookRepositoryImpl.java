package com.cognizant.fsd.springtestassignment1.repository;

//@Repository("bookRepository")
public class BookRepositoryImpl {/*
	@Override
	public Book addBook(Book book) {
		super.persist(book);
		return book;
	}

	@Override
	public boolean deleteBook(long bookId) {
		boolean flag = false;
		try {
			Book book = (Book) getSession().get(Book.class, bookId);
			super.delete(book);
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public Book searchBook(long bookId) {
		Criteria criteria = getSession().createCriteria(Book.class, "BK");
		criteria.add(Restrictions.eq("BK.bookId", bookId));
		Object book = (Object) criteria.uniqueResult();
		return book != null ? (Book) book : null;
	}

	@Override
	public List<Book> fetchAllBook() {
		Criteria criteria = getSession().createCriteria(Book.class, "BK");
		List<Book> bookList = criteria.list();
		return bookList;
	}

*/}
