package com.cognizant.fsd.springtestassignment1.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.springtestassignment1.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, Long>{
	
}
