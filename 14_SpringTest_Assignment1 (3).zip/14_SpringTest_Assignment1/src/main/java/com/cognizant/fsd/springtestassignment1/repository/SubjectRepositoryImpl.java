package com.cognizant.fsd.springtestassignment1.repository;

//@Repository("subjectRepository")
public class SubjectRepositoryImpl{/*

	@Override
	public Subject addSubject(Subject subject) {
	super.persist(subject);		
	return subject;
	}

	@Override
	public boolean deleteSubject(long subjectId) {
		boolean flag=false;
		try {
			Subject subject=(Subject) getSession().load(Subject.class, subjectId);
		super.delete(subject);
		flag=true;
		}catch(Exception e) {
			flag=false;
		}
		return flag;
	}

	
	@Override
	public Subject searchSubject(long subjectId) {
		Object subject=getSession().get(Subject.class, subjectId);
		return subject!=null?(Subject)subject:null;
	}

	

	@Override
	public List<Subject> fetchAllSubject() {		
		Criteria criteria= getSession().createCriteria(Subject.class,"SUB");
		List<Subject> subjectList=criteria.list();
		return subjectList;
	}
*/}
