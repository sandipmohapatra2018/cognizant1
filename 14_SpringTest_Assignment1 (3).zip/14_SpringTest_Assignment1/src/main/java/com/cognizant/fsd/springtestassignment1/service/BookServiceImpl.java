package com.cognizant.fsd.springtestassignment1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.springtestassignment1.model.Book;
import com.cognizant.fsd.springtestassignment1.repository.BookRepository;

@Service("bookService")
@Transactional
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepository bookRepository;

	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	@Override
	public Book addBook(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public boolean deleteBook(long bookId) {
		bookRepository.deleteById(bookId);
		return true;
	}

	@Override
	public Book searchBook(long bookId) {
		Optional<Book> book=bookRepository.findById(bookId);
		return book!=null?book.get():null;
	}

	@Override
	public List<Book> fetchAllBook() {
		return (List<Book>) bookRepository.findAll();
	}
}

