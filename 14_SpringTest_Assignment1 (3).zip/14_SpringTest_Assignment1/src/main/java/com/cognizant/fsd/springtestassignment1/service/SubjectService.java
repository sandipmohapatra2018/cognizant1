package com.cognizant.fsd.springtestassignment1.service;

import java.util.List;

import com.cognizant.fsd.springtestassignment1.model.Subject;

public interface SubjectService {
	public Subject addSubject(Subject subject);
	public boolean deleteSubject(long subjectId);
	public Subject searchSubject(long subjectId);
	public List<Subject> fetchAllSubject();
}

