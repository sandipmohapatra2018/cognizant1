package com.cognizant.fsd.springtestassignment2.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.springtestassignment2.model.Book;

public interface BookRepository extends CrudRepository<Book, Long>{	

}

