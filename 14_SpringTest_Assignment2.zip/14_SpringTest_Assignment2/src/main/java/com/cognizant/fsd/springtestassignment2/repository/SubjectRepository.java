package com.cognizant.fsd.springtestassignment2.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.fsd.springtestassignment2.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, Long>{
	
}
