package com.cognizant.fsd.springtestassignment2.service;

import java.util.List;

import com.cognizant.fsd.springtestassignment2.model.Book;

public interface BookService {
	public Book addBook(Book book);
	public boolean deleteBook(long bookId);
	public Book searchBook(long bookId);
	public List<Book> fetchAllBook();
}
