package com.cognizant.fsd.springtestassignment2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.springtestassignment2.model.Subject;
import com.cognizant.fsd.springtestassignment2.repository.SubjectRepository;
@Service("subjectService")
@Transactional
public class SubjectServiceImpl implements SubjectService{
	@Autowired
	private SubjectRepository subjectRepository;

	public void setSubjectRepository(SubjectRepository subjectRepository) {
		this.subjectRepository = subjectRepository;
	}
	@Override
	public Subject addSubject(Subject subject) {
		return subjectRepository.save(subject);
	}
	@Override
	public boolean deleteSubject(long subjectId) {
		subjectRepository.deleteById(subjectId);
		return true;
	}
	@Override
	public Subject searchSubject(long subjectId) {
		Optional<Subject> subject=subjectRepository.findById(subjectId);
		return subject!=null?subject.get():null;
	}
	@Override
	public List<Subject> fetchAllSubject() {		
		return (List<Subject>) subjectRepository.findAll();
	}

}

