package com.cognizant.fsd.springtestassignment2;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.fsd.springtestassignment2.model.Book;
import com.cognizant.fsd.springtestassignment2.model.Subject;
import com.cognizant.fsd.springtestassignment2.repository.BookRepository;
import com.cognizant.fsd.springtestassignment2.repository.SubjectRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationTests {
	@Autowired
	private SubjectRepository subjectRepository;
	@Autowired
	private BookRepository bookRepository;
	//@Test
	public void saveBook() {
		//BookRepository
		Book book=new Book();
		book.setBookId(101l);
		book.setTitle("Java");		
	    //Assert.assertNotNull(bookRepository.save(book));
	    Assert.assertNull(bookRepository.save(book));

	}
	//@Test
	public void bookFindById() {
		//BookRepository
		Book book=new Book();
		book.setBookId(101l);
		book.setTitle("Java");
	    //Assert.assertNotNull(bookRepository.findById(101l).get());
	    Assert.assertNotNull(bookRepository.findById(502l).get());

	}
	@Test
	public void findAllBooks() {
		//BookRepository		
		List<Book> bookList=(List<Book>)bookRepository.findAll();
		Assert.assertEquals(bookList.size(), 3);
	}
	
	
	//@Test
	public void save() {
		//SubjectRepository
		Subject subject=new Subject();
		subject.setSubjectId(101l);
		subject.setSubTitle("Bengali");
	    Assert.assertNotNull(subjectRepository.save(subject));
	}
	//@Test
	public void findById() {
		//SubjectRepository
		Subject subject=new Subject();
		subject.setSubjectId(501l);
		subject.setSubTitle("Bengali");
	    //Assert.assertNotNull(subjectRepository.findById(501l).get());
	    Assert.assertNotNull(subjectRepository.findById(502l).get());

	}
	//@Test
	public void findAll() {
		//SubjectRepository		
		List<Subject> subjectList=(List<Subject>)subjectRepository.findAll();
		Assert.assertEquals(subjectList.size(), 2);
	}
}
