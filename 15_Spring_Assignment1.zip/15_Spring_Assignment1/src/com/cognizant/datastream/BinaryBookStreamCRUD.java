package com.cognizant.datastream;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.InitializingBean;

import com.cognizant.model.Book;

public class BinaryBookStreamCRUD implements InitializingBean{
	private String fileName = "C:\\Saugata\\binaryFile\\book.dat";
private DataOutputStream outStream = null;
	public DataOutputStream openOutputStream(String name) throws Exception {
		DataOutputStream out = null;
		File file = new File(name);
		out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
		return out;
	}

	public void writeBook(Book book){
		writeRecords(book,fileName);
	}
	private void writeRecords(Book book, String fileName )  {
		 try {		    
			   outStream.writeLong(book.getBookId());
			   outStream.writeUTF(book.getTitle());
			   outStream.writeInt(book.getVolume());
			   outStream.writeDouble(book.getPrice());
			   outStream.writeUTF(book.getPublishDate().toString());
		 } catch (IOException e) {
		   System.out.println("IOERROR:  " + e.getMessage() + "\n");
		 }
		} // writeRecords()
public List<Book> readRecords(){	
	List<Book> bookList=new ArrayList<Book>();
	try {
		DataInputStream inStream = new DataInputStream(new FileInputStream(fileName));
		  while (true) {                                            // Infinite loop
		    Long bookId = inStream.readLong();                      // Read a record
		    String title = inStream.readUTF();
		    Integer volume = inStream.readInt();
		    Double price = inStream.readDouble();
		    String publishDate = inStream.readUTF();
		    Book book=new Book();
		    book.setBookId(bookId);
		    book.setTitle(title);
		    book.setVolume(volume);
		    book.setPrice(price);
		    book.setPublishDate(stringToDate(publishDate));
		    bookList.add(book);
		  } // while
		} catch (Exception e) {
			System.out.println(bookList.size());
			System.err.println("eeeeeeee "+e);
		}
	return bookList;
}

public void open() throws Exception {
	this.outStream= new DataOutputStream(new FileOutputStream(fileName));
}
public void close() throws Exception {
	this.outStream.close();
}
	@Override
	public void afterPropertiesSet() throws Exception {
		//this.out = openOutputStream("data.dat");
	}
	
	public LocalDate stringToDate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		//convert String to LocalDate
		return LocalDate.parse(date, formatter);
	}
}




