package com.cognizant.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.datastream.BinaryBookStreamCRUD;
import com.cognizant.model.Book;
@Repository("bookRepository")
public class BookRepositoryImpl implements BookRepository{
	private List<Book> bookList=new ArrayList<Book>();
	
	private BinaryBookStreamCRUD binaryBookStreamCRUD;
		@Override
		public Book addBook(Book book) {
			bookList.add(book);
			saveToBinaryFile(bookList);
			return book;
		}

		@Override
		public boolean deleteBook(long bookId) {
			boolean flag=bookList.removeIf(book->book.getBookId()==bookId);
			saveToBinaryFile(bookList);
			return flag;
		}

		@Override
		public Book searchBook(long bookId) {
			Book book=null;
			try {
				bookList=binaryBookStreamCRUD.readRecords();
			book= bookList.stream()
					.filter(b -> b.getBookId() == bookId).reduce((a, b) -> {
					throw new IllegalStateException("Multiple elements: " + a + ", " + b);
				}).get();
			}catch(Exception exception) {}
			return book;
		}
		public void saveToBinaryFile(List<Book> bookList) {
			try {
				binaryBookStreamCRUD.open();
				bookList.forEach(b->{
					binaryBookStreamCRUD.writeBook(b);
				});	
				binaryBookStreamCRUD.close();
			} catch (Exception e) {		
				e.printStackTrace();
			}
		}
		@Override
		public List<Book> fetchAllBook() {
			return bookList;
		}

		public BinaryBookStreamCRUD getBinaryBookStreamCRUD() {
			return binaryBookStreamCRUD;
		}

		public void setBinaryBookStreamCRUD(BinaryBookStreamCRUD binaryBookStreamCRUD) {
			this.binaryBookStreamCRUD = binaryBookStreamCRUD;
		}
		

}
