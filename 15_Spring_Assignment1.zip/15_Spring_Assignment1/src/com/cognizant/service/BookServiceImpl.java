package com.cognizant.service;

import java.util.List;

import com.cognizant.model.Book;
import com.cognizant.repository.BookRepository;

public class BookServiceImpl implements BookService {
	private BookRepository bookRepository;

	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	@Override
	public Book addBook(Book book) {
		return bookRepository.addBook(book);
	}

	@Override
	public boolean deleteBook(long bookId) {
		return bookRepository.deleteBook(bookId);
	}

	@Override
	public Book searchBook(long bookId) {
		return bookRepository.searchBook(bookId);
	}

	@Override
	public List<Book> fetchAllBook() {
		return bookRepository.fetchAllBook();
	}
}
