package com.cognizant.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.Subject;
import com.cognizant.repository.SubjectRepository;

@Service("subjectService")
public class SubjectServiceImpl implements SubjectService{
	private SubjectRepository subjectRepository;

	public void setSubjectRepository(SubjectRepository subjectRepository) {
		this.subjectRepository = subjectRepository;
	}
	@Override
	public Subject addSubject(Subject subject) {
		return subjectRepository.addSubject(subject);
	}
	@Override
	public boolean deleteSubject(long subjectId) {		
		return subjectRepository.deleteSubject(subjectId);
	}
	@Override
	public Subject searchSubject(long subjectId) {	
		return subjectRepository.searchSubject(subjectId);
	}
	@Override
	public List<Subject> fetchAllSubject() {		
		return subjectRepository.fetchAllSubject();
	}

}
