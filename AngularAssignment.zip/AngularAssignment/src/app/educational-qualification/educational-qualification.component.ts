import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { EducationalQualification } from '../model/educational-qualification';
import { ModalService } from '../service/modal.service';
import { NgbdModalBasic } from '../modal-basic';
@Component({
  selector: 'app-educational-qualification',
  templateUrl: './educational-qualification.component.html',
  styleUrls: ['./educational-qualification.component.css']
})
export class EducationalQualificationComponent implements OnInit {
  private fieldArray: Array<EducationalQualification> = [];
  private newAttribute: any = {};
  private editEducationalQualification: EducationalQualification;
  //constructor(private modalService: ModalService) { }

  addFieldValue() {
      this.fieldArray.push(this.newAttribute)
      this.newAttribute = {};
  }

  deleteFieldValue(index) {
      this.fieldArray.splice(index, 1);
  }
  editFieldValue(index){
    let educationalQualification=this.fieldArray[index];
    //this.ngbdModalBasic.open(null);
    console.log("KKKK "+educationalQualification.qualification);
    
    
  }

  ngOnInit() {
  }
















  closeResult: string;
  
    constructor(private modalService: NgbModal) {}
  
    open(content:any,index) {
      let educationalQualification=this.fieldArray[index];
      this.editEducationalQualification=educationalQualification;
      
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        //this.closeResult = `Closed with: ${result}`;

        if('save_click'===result){
          console.log("save_click :"+result);
        }
        
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
  
    private getDismissReason(reason: any): string {
      if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
      } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
      } else {
        return  `with: ${reason}`;
      }
    }
}
