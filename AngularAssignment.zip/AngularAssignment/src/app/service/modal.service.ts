import { Injectable } from '@angular/core';
import { EducationalQualification } from '../model/educational-qualification';
import * as _ from 'underscore';

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  public fieldArray: Array<EducationalQualification> = [];

  
    
}
