import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { Assignment2Component } from './assignment2/assignment2.component';
import { PostEditComponent } from './post-edit/post-edit.component'; 

const routes: Routes = [
  { path: 'assign2', component: Assignment2Component },
  
  { path: 'assign2/:id', component: PostEditComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
  ],
  exports: [ RouterModule ]

})
export class AppRoutingModule { }
