import { Component, OnInit } from '@angular/core';
import { Assignment2serviceService } from './assignment2service.service';
@Component({
  selector: 'app-assignment2',
  templateUrl: './assignment2.component.html',
  styleUrls: ['./assignment2.component.css']
})
export class Assignment2Component implements OnInit {

 
  posts = [];

  constructor(private ass2Service: Assignment2serviceService) { }

  ngOnInit() {
    this.getPosts()
  }

  getPosts(): void {
    this.ass2Service.getPosts().then(posts => this.posts = posts);;
  }

  onDelete(id: number): void {
    this.ass2Service.deletePosts(id).then(response => {
      this.getPosts();
    });
  }

}
