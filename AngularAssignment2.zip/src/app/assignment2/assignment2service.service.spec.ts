import { TestBed, inject } from '@angular/core/testing';

import { Assignment2serviceService } from './assignment2service.service';

describe('Assignment2serviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Assignment2serviceService]
    });
  });

  it('should be created', inject([Assignment2serviceService], (service: Assignment2serviceService) => {
    expect(service).toBeTruthy();
  }));
});
