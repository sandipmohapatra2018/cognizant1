import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Assignment2serviceService {
  private heroesUrl = 'https://jsonplaceholder.typicode.com';  // URL to web api


  constructor(private http: HttpClient) { }

  getPosts(): Promise<any> {

    /* this.http.get(this.heroesUrl).subscribe(data => {
       console.log(data);
       return data;
     });*/
    return this.get(this.heroesUrl+'/posts');
  }

  getPost(id) {
    debugger
    return this.get(this.heroesUrl + '/posts/' + id);
  }




  deletePosts(id): Promise<any> {

    return this.http.delete('https://jsonplaceholder.typicode.com/posts/' + id)
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();
  }



  get(url) {
    return this.http.get(url)
      .toPromise()
      .then(response => { console.log('pravat 123'); console.log(response); return response })
      .catch();
  }



  editPosts(hero, id) {
    // return this.http.put(url, JSON.stringify(customer), {headers: this.headers});

    return this.http.put('https://jsonplaceholder.typicode.com/posts/' + id, JSON.stringify(hero))
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();

  }

  createPost(hero) {
    return this.http.post('https://jsonplaceholder.typicode.com/posts', JSON.stringify(hero))
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();
  }

  saveData(postData, id) {

    if (id != undefined && id > 0) {
      return this.editPosts(postData, id)
    
    } else {
      return this.createPost(postData);
    }

  }




}
