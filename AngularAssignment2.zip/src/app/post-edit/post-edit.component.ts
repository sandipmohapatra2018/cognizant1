import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Assignment2serviceService } from '../assignment2/assignment2service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-post-edit',
  templateUrl: './post-edit.component.html',
  styleUrls: ['./post-edit.component.css']
})
export class PostEditComponent implements OnInit {

  id;

  // postId:number;
  // postSubject:string;
  // postDetails:string;

  postData = {
    id: '',
    userId: '',
    title: '',
    body: ''
  }



  constructor(private route: ActivatedRoute,
    private location: Location,
    private ass2Service: Assignment2serviceService
  ) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this.id = id;
    alert(id);
    if( id == "0"){
      return
    }
    this.getHero(id);
  }


  getHero(id): void {
    // const id = this.route.snapshot.paramMap.get('id');

    this.ass2Service.getPost(id).then(response => {
      this.postData.title = response["title"];
      this.postData.body = response["body"];
      this.postData.id = response["id"];
      this.postData.userId = response["userId"];

      alert(JSON.stringify(this.postData));
    });

  }

  save(): void {
    this.ass2Service.saveData(this.postData, this.postData.id).then(response => {
      alert(JSON.stringify(response));
      alert(" Saved sucessfully   ");
    });

  }

  
  goBack(): void {
    this.location.back();
  }


}
