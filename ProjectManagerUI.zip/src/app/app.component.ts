import { Component, OnInit } from '@angular/core';
import { NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { Task } from './model/task';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  title = 'Project Manager';
  taskreserve :any;

  constructor( private tab :NgbTabset){
  }
  ngOnInit() {
    console.log(this.tab.activeId);
  }

  public saveSelectedTask(item :any){
      this.taskreserve = item;
  }
}
