import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { TaskComponent } from './task/task.component';
import { ProjectComponent } from './project/project.component';
import { NgbModule, NgbTabset, NgbModal, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { UserService } from './service/user.service';
import { Configuration } from './configuration/server.configuration';
import { Logger } from './utillity/logger.service';
import { HttpClientModule } from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { ProjectService } from './service/project.service';
import { UsersearchComponent } from './popup/usersearch/usersearch.component';
import { TasksearchComponent } from './popup/tasksearch/tasksearch.component';
import { ProjectsearchComponent } from './popup/projectsearch/projectsearch.component';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    TaskComponent,
    ProjectComponent,
    UsersearchComponent,
    TasksearchComponent,
    ProjectsearchComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    ReactiveFormsModule,
    HttpClientModule,
    AngularFontAwesomeModule
  ],
  providers: [NgbTabset,NgbDatepicker, DatePipe, UserService,NgbModal, ProjectService, Logger, Configuration],
  bootstrap: [AppComponent]
})
export class AppModule { }
