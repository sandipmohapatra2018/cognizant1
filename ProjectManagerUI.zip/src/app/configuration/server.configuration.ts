
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class Configuration {
    public Server = 'http://localhost:8090/projectmanager/webapi/users';
    public ApiUrl = '';
    public ServerWithApiUrl = this.Server + this.ApiUrl;
    public headers = new HttpHeaders({'Content-Type':'application/json'});
    /*
    ,
    'Access-Control-Allow-Origin' : '*',
    "Access-Control-Allow-Methods" : "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
    */
}