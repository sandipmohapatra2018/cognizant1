export class ParentTask{
    parentTaskId :number;
    taskName :string;
  }