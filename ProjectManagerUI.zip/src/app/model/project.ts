export class Project{
    projectId :number;
    title :string;
    priority :number;
    managerId :string;
    managerName :string;
    startDate:string;
    endDate:string;
    isActive:boolean;
  }