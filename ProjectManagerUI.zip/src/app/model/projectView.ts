import { User } from "./user";

export class ProjectView{
    projectId :number;
    title :string;
    priority :number;
    manager :User;
    startDate:string;
    endDate:string;
    noOfTasks:number;
    completed:number;
    isActive:boolean;
  }