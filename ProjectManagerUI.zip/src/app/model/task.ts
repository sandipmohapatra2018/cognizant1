import { Project } from "./project";
import { User } from "./user";
import { ParentTask } from "./ParentTask";

export class Task{
    taskId :number;
    taskName :string;
    priority :number;
    parentTaskId :number;
    parentTask :ParentTask;
    projectId :number;
    project :Project;
    startDate:string;
    endDate:string;
    userId :number;
    user :User;
    isActive:boolean;
    isParent :boolean;
    status:string;
  }