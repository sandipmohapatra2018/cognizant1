import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectsearchComponent } from './projectsearch.component';
import { Logger } from '../../utillity/logger.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Configuration } from '../../configuration/server.configuration';

describe('ProjectsearchComponent', () => {
  let component: ProjectsearchComponent;
  let fixture: ComponentFixture<ProjectsearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectsearchComponent ],
      providers:[Logger,HttpClient,HttpHandler,Configuration]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
