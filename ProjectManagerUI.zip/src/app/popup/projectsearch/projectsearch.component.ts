import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { ProjectView } from '../../model/projectView';
import { NgbModalRef, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Logger } from '../../utillity/logger.service';
import { ProjectService } from '../../service/project.service';

@Component({
  selector: 'app-projectsearch',
  templateUrl: './projectsearch.component.html',
  styleUrls: ['./projectsearch.component.css']
})
export class ProjectsearchComponent implements OnInit {

  closeResult: string;
  projectList : ProjectView[];
  private modalRef: NgbModalRef;
  @ViewChild('content') content: ElementRef;
  
  constructor(private modalService: NgbModal,
     private projectService:ProjectService,
    private _logger :Logger) {}

  @Output() setSelectedProject: EventEmitter<any> = new EventEmitter();

  openSearchProjectModal() {
    this.modalRef = this.modalService.open(this.content, {ariaLabelledBy: 'modal-basic-title',size:'lg',windowClass:'cutomModalHeight'});
    this.modalRef.result.then((result) => {this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
}
  ngOnInit() {
    this.projectService.getProjects().then(projects => 
      {
          this.projectList = projects;
         // this.tableComp.getTasksView();
          //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public onSearch(event: any){
    this._logger.log('--Searching For ---:'+event.target.value);
    let query = event.target.value;
    this.projectService.searchprojects(query).then(projects => 
      {
          this.projectList = projects;
        // this.tableComp.getTasksView();
        //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public selectProject(project : any){
      console.log(project);
      this.setSelectedProject.emit(project);
      this.modalRef.close('Project Selected.');
  }
}
