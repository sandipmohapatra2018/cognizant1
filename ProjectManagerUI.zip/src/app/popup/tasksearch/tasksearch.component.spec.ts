import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TasksearchComponent } from './tasksearch.component';
import { Logger } from '../../utillity/logger.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Configuration } from '../../configuration/server.configuration';

describe('TasksearchComponent', () => {
  let component: TasksearchComponent;
  let fixture: ComponentFixture<TasksearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TasksearchComponent ],
      providers:[Logger,HttpClient,HttpHandler,Configuration]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TasksearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
