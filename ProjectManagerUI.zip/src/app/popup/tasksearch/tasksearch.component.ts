import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { ParentTask } from '../../model/ParentTask';
import { NgbModalRef, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Logger } from '../../utillity/logger.service';
import { TaskService } from '../../service/task.service';

@Component({
  selector: 'app-tasksearch',
  templateUrl: './tasksearch.component.html',
  styleUrls: ['./tasksearch.component.css']
})
export class TasksearchComponent implements OnInit {

  closeResult: string;
  parentTaskList : ParentTask[];
  private modalRef: NgbModalRef;
  @ViewChild('content') content: ElementRef;
  
  constructor(private modalService: NgbModal,
     private taskService:TaskService,
    private _logger :Logger) {}

  @Output() setSelectedTask: EventEmitter<any> = new EventEmitter();

  openSearchTaskModal() {
    this.modalRef = this.modalService.open(this.content, {ariaLabelledBy: 'modal-basic-title',size:'lg',windowClass:'cutomModalHeight'});
    this.modalRef.result.then((result) => {this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
}
  ngOnInit() {
    this.taskService.getParentTasks().then(tasks => 
      {
          this.parentTaskList = tasks;
         // this.tableComp.getTasksView();
          //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public onSearch(event: any){
    this._logger.log('--Searching For ---:'+event.target.value);
    let query = event.target.value;
    this.taskService.searchParentTasks(query).then(tasks => 
      {
          this.parentTaskList = tasks;
        // this.tableComp.getTasksView();
        //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public selectTask(parentTask : any){
      console.log(parentTask);
      this.setSelectedTask.emit(parentTask);
      this.modalRef.close('Project Selected.');
  }
}