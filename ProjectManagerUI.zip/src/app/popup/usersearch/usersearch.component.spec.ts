import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersearchComponent } from './usersearch.component';
import { Logger } from '../../utillity/logger.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Configuration } from '../../configuration/server.configuration';

describe('UsersearchComponent', () => {
  let component: UsersearchComponent;
  let fixture: ComponentFixture<UsersearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsersearchComponent ],
      providers:[Logger,HttpClient,HttpHandler,Configuration],
      schemas:[CUSTOM_ELEMENTS_SCHEMA],
      imports:[NgbModule.forRoot(),ReactiveFormsModule,FormsModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
