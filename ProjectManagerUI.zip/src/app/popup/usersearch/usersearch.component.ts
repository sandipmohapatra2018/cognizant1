import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { User } from '../../model/user';
import { UserService } from '../../service/user.service';
import { Logger } from '../../utillity/logger.service';

@Component({
  selector: 'app-usersearch',
  templateUrl: './usersearch.component.html',
  styleUrls: ['./usersearch.component.css']
})
export class UsersearchComponent implements OnInit {
  closeResult: string;
  userlist : User[];
  private modalRef: NgbModalRef;
  @ViewChild('content') content: ElementRef;
  
  constructor(private modalService: NgbModal,
     private userService:UserService,
    private _logger :Logger) {}

  @Output() setSelectedUser: EventEmitter<any> = new EventEmitter();

  openSearchUserModal() {
    this.modalRef = this.modalService.open(this.content, {ariaLabelledBy: 'modal-basic-title',size:'lg',windowClass:'cutomModalHeight'});
    this.modalRef.result.then((result) => {this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
}
  ngOnInit() {
    this.userService.getUsers().then(users => 
      {
          this.userlist = users;
         // this.tableComp.getTasksView();
          //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public onSearch(event: any){
    this._logger.log('--Searching For ---:'+event.target.value);
    let query = event.target.value;
    this.userService.searchUsers(query).then(users => 
      {
          this.userlist = users;
        // this.tableComp.getTasksView();
        //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }

  public selectUser(user : any){
      console.log(user);
      this.setSelectedUser.emit(user);
      this.modalRef.close('User Selected.');
  }
}
