import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectComponent } from './project.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Logger } from '../utillity/logger.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Configuration } from '../configuration/server.configuration';
import { DatePipe } from '@angular/common';

describe('ProjectComponent', () => {
  let component: ProjectComponent;
  let fixture: ComponentFixture<ProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectComponent ],
      imports:[NgbModule.forRoot(),ReactiveFormsModule,FormsModule],
      schemas:[CUSTOM_ELEMENTS_SCHEMA],
      providers:[Logger,HttpClient,HttpHandler,Configuration,DatePipe]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
