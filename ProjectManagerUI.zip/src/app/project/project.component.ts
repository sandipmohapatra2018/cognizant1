import { Component, OnInit, ViewChild } from '@angular/core';
import { Project } from '../model/project';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Logger } from '../utillity/logger.service';
import { ProjectService } from '../service/project.service';
import { UsersearchComponent } from '../popup/usersearch/usersearch.component';
import { DatePipe } from '@angular/common';
import { ProjectView } from '../model/projectView';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {
 
  isUpdate = false;
  isAdd = true;
  isSearchingProject = false;
  project :Project;
  projectList : ProjectView[];
  datesValidated = false;

  projectForm = new FormGroup({
    projectTitle: new FormControl(''),
    priorityValue: new FormControl(''),
    setDates:new FormControl(''),
    startDate:new FormControl(''),
    endDate:new FormControl(''),
    managerId:new FormControl(''),
    managerName :new FormControl('')
  });
  
  @ViewChild(UsersearchComponent) searchUserModal :UsersearchComponent;

  constructor(private _logger : Logger,
     private fb: FormBuilder,
    private projectService : ProjectService,
    private datePipe: DatePipe) { }

  ngOnInit() {
    this.createForm();

    /*disabled date and user search
     field after form intialized
    * */
    this.projectForm.controls['startDate'].disable();
    this.projectForm.controls['endDate'].disable();
    this.projectForm.controls['managerName'].disable();

    this.getProjects();
    
  }

  private createForm() {
    let setDates = false;
    if(this.project != null){
       let _tempproject = this.project
       if(_tempproject.startDate != null)
       setDates = true;
        this.projectForm = this.fb.group({
            projectTitle: [_tempproject.title,Validators.required ],
            priorityValue: [_tempproject.priority],
            managerId:[_tempproject.managerId],
            setDates:[setDates],
            startDate:[this.datePipe.transform(_tempproject.startDate,'yyyy-MM-dd')],
            endDate:[this.datePipe.transform(_tempproject.endDate,'yyyy-MM-dd')],
            managerName:[_tempproject.managerName, Validators.required]
        });
    }else{
      this.projectForm = this.fb.group({
        projectTitle: ['',Validators.required ],
        priorityValue: [0],
        setDates:[setDates],
        startDate:[''],
        endDate:[''],
        managerId:[''],
        managerName:['', Validators.required]
      });
    }
  }

  //Adding new Project in the Application
  public addNewProject($event){
    console.log(this.projectForm.controls['projectTitle'].value);
    let project : Project;
    project = {
      'projectId' :null,
      'title':this.projectForm.controls['projectTitle'].value,
      'priority':this.projectForm.controls['priorityValue'].value,
      'managerId':this.projectForm.controls['managerId'].value,
      'startDate':this.projectForm.controls['startDate'].value !=null ?this.datePipe.transform(this.projectForm.controls["startDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'endDate':this.projectForm.controls['endDate'].value !=null ?this.datePipe.transform(this.projectForm.controls["endDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'isActive':true,
      'managerName':this.projectForm.controls['managerName'].value
  };
  console.log(project);
  this.projectService.addProject(project).then((res) => {
    this.projectForm.reset();
    this.getProjects();
  })
  }

  //get all the Projects details available in the application
  private getProjects(){
    this._logger.log("Calling get All Projects");
    return this.projectService.getProjects().then(projects => 
        {
            this.projectList = projects;
        },(error) => {
            this._logger.log(error);
            });
}

//reset project Form
public resetProjectForm($event){
  this.projectForm.reset();
  this.projectForm.controls['startDate'].disable();
  this.projectForm.controls['endDate'].disable();
}
// Logic on set start and end date checkbox
public enableDisableDates(event : any){
  console.log('Click Called :'+this.projectForm.controls['setDates'].value);
if(!this.projectForm.controls['setDates'].value){
   
    this.projectForm.controls['startDate'].enable();
    this.projectForm.controls['endDate'].enable();
    this.projectForm.controls['startDate'].setValidators([Validators.required]);
    this.projectForm.controls['endDate'].setValidators([Validators.required]);
    let currentDate = new Date();
    this.projectForm.controls['startDate'].setValue(this.datePipe.transform(currentDate,'yyyy-MM-dd'), Validators.required)
    this.projectForm.controls['endDate'].setValue(this.datePipe.transform(currentDate.setDate(currentDate.getDate() + 1),'yyyy-MM-dd'));
    this.error={isError:false,errorMessage:''};
    this.datesValidated = false;
}else{
    this.projectForm.controls['startDate'].reset();
    this.projectForm.controls['startDate'].disable();
    this.projectForm.controls['endDate'].reset();
    this.projectForm.controls['endDate'].disable();
}
}
//Search user Popup
public openUserSearch(valueHolder :string){
  this.searchUserModal.openSearchUserModal();
}

setSelectedUser(user:any){
  this._logger.log(user.firstName);
  this.projectForm.controls['managerName'].setValue(user.firstName+' '+user.lastName);
  this.projectForm.controls['managerId'].setValue(user.userId);
  this._logger.log(this.projectForm.controls['managerId'].value);
}

//edit Project details
public editProject(item :any){
  this._logger.log("calling edit form :"+item.projectId);
  this.project = {
    'projectId' :item.projectId,
    'title':item.title,
    'priority':item.priority,
    'managerId':item.manager.userId,
    'startDate':item.startDate,
    'endDate':item.endDate,
    'isActive':true,
    'managerName':item.manager.firstName+' '+item.manager.lastName
};
    this.projectForm.controls['startDate'].enable();
    this.projectForm.controls['endDate'].enable();  
    this.createForm();
  if(this.project.startDate != null){
    this.projectForm.controls['startDate'].enable();
    this.projectForm.controls['endDate'].enable();
    this.projectForm.controls['startDate'].setValidators([Validators.required]);
    this.projectForm.controls['endDate'].setValidators([Validators.required]);
    this.projectForm.controls['setDates'].setValue(true);
  }else{
    this.projectForm.controls['startDate'].disable();
    this.projectForm.controls['endDate'].disable();
    this.projectForm.controls['startDate'].clearValidators();
    this.projectForm.controls['endDate'].clearValidators();
    this.projectForm.controls['setDates'].setValue(false);
  }

  if(!this.isUpdate)
      this.toggleButton();
    window.scrollTo({top:0,behavior: 'smooth'});
}

//update Project details in database

public updateProjectDetails($event){

  let temp : Project;
  temp = {
      'projectId' :this.project.projectId,
      'title':this.projectForm.controls['projectTitle'].value,
      'priority':this.projectForm.controls['priorityValue'].value,
      'managerId':this.projectForm.controls['managerId'].value,
      'managerName':this.projectForm.controls['managerName'].value,
      'startDate':this.projectForm.controls['startDate'].value !=null ?this.datePipe.transform(this.projectForm.controls["startDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'endDate':this.projectForm.controls['endDate'].value !=null ?this.datePipe.transform(this.projectForm.controls["endDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'isActive':true
  };
  this._logger.log(temp);
  this.project = null;
  this.projectService.updateProjectDetails(temp).then((res) => { 
    this.projectForm.reset();
    this.getProjects();
    if(this.isUpdate)
      this.toggleButton();
})
}

//Delete User
public suspendProject(id:any){
  this._logger.log("deleted now-->"+id);
  this.projectService.suspendProject(id).then((res) => {
    this.getProjects(); 
})
}

//Searching Project View
public onSearchProject(event: any){
  this._logger.log('--Searching For ---:'+event.target.value);
  let query = event.target.value;
  this.isSearchingProject = true;
  this.projectService.searchprojects(query).then(projects => 
    {
        this.projectList = projects;
    },(error) => {
        this._logger.log(error);
        });
}
//Sort Projects List by selected
sortOrder = 'DESC';
public sortProjects(sortBy :string){
    if(this.sortOrder == 'DESC'){
      this.sortOrder = 'ASC';
    }else{
      this.sortOrder = 'DESC';
    }
    this.projectService.sortProjects({'sortBy':sortBy,'sortOrder':this.sortOrder}).then(projects => 
      {
          this.projectList = projects;
      },(error) => {
          this._logger.log(error);
          });
  }


public cancelProjectUpdate($event){
  this.project = null;
  this.createForm();
  if(this.isUpdate)
      this.toggleButton();
}

private toggleButton() {
  this.isAdd = !this.isAdd;
  this.isUpdate = !this.isUpdate;
}

//Start and End dates validation
error:any={isError:false,errorMessage:''};
compareTwoDates(){
   if(new Date(this.projectForm.controls['endDate'].value) < new Date(this.projectForm.controls['startDate'].value)){
      this.error={isError:true,errorMessage:'End Date can not before start date'};
      this.datesValidated = true;
   }else{
    this.error={isError:false,errorMessage:''};
    this.datesValidated = false;
   }
}

}