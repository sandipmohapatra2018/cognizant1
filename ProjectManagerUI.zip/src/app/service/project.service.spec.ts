import { TestBed, inject } from '@angular/core/testing';

import { ProjectService } from './project.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Logger } from '../utillity/logger.service';
import { Configuration } from '../configuration/server.configuration';

describe('ProjectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[ProjectService, Logger,HttpClient,HttpHandler,Configuration]
    });
  });

  it('should be created', inject([ProjectService], (service: ProjectService) => {
    expect(service).toBeTruthy();
  }));
});
