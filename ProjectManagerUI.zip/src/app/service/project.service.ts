import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Logger } from '../utillity/logger.service';
import { User } from '../model/user';
import { DomSanitizer } from '@angular/platform-browser';
import { Configuration } from '../configuration/server.configuration';
import { Project } from '../model/project';
import { ProjectView } from '../model/projectView';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  private actionUrl: string;
  private headers :HttpHeaders;

    constructor(private _logger: Logger,private http: HttpClient, public sanitizer: DomSanitizer, _configuration: Configuration) {
        this.actionUrl = _configuration.Server+'/projects';
        this.headers = _configuration.headers;
    }
  // Get all Tasks
  getProjects(): Promise<ProjectView[]> {
    console.log(this.actionUrl);
    return this.http.get(this.actionUrl)
                .toPromise()
                .then(response => response as ProjectView[])
                .catch(this.handleError);
  }

 // add new user
    addProject(project: Project): Promise<User> {
      this._logger.log('Project Details:'+JSON.stringify(project));
      return this.http
        .post(this.actionUrl, JSON.stringify(project),{headers:this.headers})
        .toPromise()
        .then(res => res as Project)
        .catch(this.handleError);
    }

//Update Project Details
updateProjectDetails(project: Project): Promise<User> {
  const url = `${this.actionUrl}/${project.projectId}`;
  return this.http
    .put(url, JSON.stringify(project), {headers: this.headers})
    .toPromise()
    .then(() => project)
    .catch(this.handleError);
}

//Suspend Project
suspendProject(id: number): Promise<void> {
  const url = `${this.actionUrl}/${id}`;
  return this.http.delete(url, {headers: this.headers})
    .toPromise()
    .then(() => null)
    .catch(this.handleError);
}

//search Projects by title

 // Get all projects
 searchprojects(query : string): Promise<ProjectView[]> {
  const url = `${this.actionUrl}/search/${query}`;
  console.log(this.actionUrl);
  return this.http.get(url)
              .toPromise()
              .then(response => response as ProjectView[])
              .catch(this.handleError);
}

//Sorting Project view list

// Get all Projects
sortProjects(query : any): Promise<ProjectView[]> {
  const url = `${this.actionUrl}`;
  let params = new HttpParams()
                .set('sortBy',query.sortBy)
                .set('sortOrder',query.sortOrder);
  this._logger.log(params.keys());
  return this.http.get(url,{params:params})
              .toPromise()
              .then(response => response as ProjectView[])
              .catch(this.handleError);
}

private handleError(error: any): Promise<any> {
  return Promise.reject(error.message || error);
}
}
