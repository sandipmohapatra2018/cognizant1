import { TestBed, inject } from '@angular/core/testing';

import { TaskService } from './task.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Logger } from '../utillity/logger.service';
import { Configuration } from '../configuration/server.configuration';

describe('TaskService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TaskService,Logger,HttpClient,HttpHandler,Configuration]
    });
  });

  it('should be created', inject([TaskService], (service: TaskService) => {
    expect(service).toBeTruthy();
  }));
});
