import { Injectable } from '@angular/core';
import { Task } from '../model/task';
import { HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';
import { Logger } from '../utillity/logger.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Configuration } from '../configuration/server.configuration';
import { ParentTask } from '../model/ParentTask';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  
  private actionUrl: string;
  private headers :HttpHeaders;

    constructor(private _logger: Logger,private http: HttpClient, public sanitizer: DomSanitizer, _configuration: Configuration) {
        this.actionUrl = _configuration.Server+'/tasks';
        this.headers = _configuration.headers;
    }
//Search parent Task List
    searchParentTasks(query : string): Promise<ParentTask[]> {
      const url = `${this.actionUrl}/parenttask/search/${query}`;
      console.log(this.actionUrl);
      return this.http.get(url)
                  .toPromise()
                  .then(response => response as ParentTask[])
                  .catch(this.handleError);
    }

//Get All Parent Task

    getParentTasks(): Promise<ParentTask[]> {
      console.log(this.actionUrl);
      return this.http.get(this.actionUrl+"/parenttask")
                  .toPromise()
                  .then(response => response as ParentTask[])
                  .catch(this.handleError);
    }
  // Get all Tasks
  getTasks(): Promise<Task[]> {
    console.log(this.actionUrl);
    return this.http.get(this.actionUrl)
                .toPromise()
                .then(response => response as Task[])
                .catch(this.handleError);
  }

 // add new Task
    addTask(task: Task): Promise<Task> {
      this._logger.log('Project Details:'+JSON.stringify(task));
      return this.http
        .post(this.actionUrl, JSON.stringify(task),{headers:this.headers})
        .toPromise()
        .then(res => res as Task)
        .catch(this.handleError);
    }

    // add new Parent Task
    addParentTask(task: ParentTask): Promise<ParentTask> {
      this._logger.log('Project Details:'+JSON.stringify(task));
      return this.http
        .post(this.actionUrl+'/parenttask', JSON.stringify(task),{headers:this.headers})
        .toPromise()
        .then(res => res as ParentTask)
        .catch(this.handleError);
    }

//Update Task Details
updateTaskDetails(task: Task): Promise<Task> {
  const url = `${this.actionUrl}/${task.taskId}`;
  return this.http
    .put(url, JSON.stringify(task), {headers: this.headers})
    .toPromise()
    .then(() => task)
    .catch(this.handleError);
}

//end Task
endTask(id: number): Promise<void> {
  const url = `${this.actionUrl}/${id}`;
  return this.http.delete(url, {headers: this.headers})
    .toPromise()
    .then(() => null)
    .catch(this.handleError);
}

//search Projects by title

 // Get all Tasks
 searchTasks(query : string): Promise<Task[]> {
  const url = `${this.actionUrl}/search/${query}`;
  console.log(this.actionUrl);
  return this.http.get(url)
              .toPromise()
              .then(response => response as Task[])
              .catch(this.handleError);
}

//Sorting Tasks view list

// Get all Projects
sortProjectTasks(query : any): Promise<Task[]> {
  const url = `${this.actionUrl}/search/${query.projectId}`;
  let params = new HttpParams()
                .set('sortBy',query.sortBy)
                .set('sortOrder',query.sortOrder);
  this._logger.log(params.keys());
  return this.http.get(url,{params:params})
              .toPromise()
              .then(response => response as Task[])
              .catch(this.handleError);
}

private handleError(error: any): Promise<any> {
  return Promise.reject(error.message || error);
}
}
