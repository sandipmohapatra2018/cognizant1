import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Logger } from '../utillity/logger.service';
import { User } from '../model/user';
import { DomSanitizer } from '@angular/platform-browser';
import { Configuration } from '../configuration/server.configuration';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private actionUrl: string;
  private headers :HttpHeaders;

    constructor(private _logger: Logger,private http: HttpClient, public sanitizer: DomSanitizer, _configuration: Configuration) {
        this.actionUrl = _configuration.Server;
        this.headers = _configuration.headers;
    }
  // Get all Tasks
  getUsers(): Promise<User[]> {
    console.log(this.actionUrl);
    return this.http.get(this.actionUrl)
                .toPromise()
                .then(response => response as User[])
                .catch(this.handleError);
  }

 // add new user
    addUser(user: User): Promise<User> {
      this._logger.log('User Name:'+JSON.stringify(user));
      return this.http
        .post(this.actionUrl, JSON.stringify(user),{headers:this.headers})
        .toPromise()
        .then(res => res as User)
        .catch(this.handleError);
    }

//Update User Details
updateUserDetails(user: User): Promise<User> {
  const url = `${this.actionUrl}/${user.userId}`;
  return this.http
    .put(url, JSON.stringify(user), {headers: this.headers})
    .toPromise()
    .then(() => user)
    .catch(this.handleError);
}

//Delete user
deleteUser(id: number): Promise<void> {
  const url = `${this.actionUrl}/${id}`;
  return this.http.delete(url, {headers: this.headers})
    .toPromise()
    .then(() => null)
    .catch(this.handleError);
}

//search users by Fist and last Names

 // Get all Tasks
 searchUsers(query : string): Promise<User[]> {
  const url = `${this.actionUrl}/search/${query}`;
  console.log(this.actionUrl);
  return this.http.get(url)
              .toPromise()
              .then(response => response as User[])
              .catch(this.handleError);
}

//Sorting user list

// Get all Tasks
sortUsers(query : any): Promise<User[]> {
  const url = `${this.actionUrl}`;
  let params = new HttpParams()
                .set('sortBy',query.sortBy)
                .set('sortOrder',query.sortOrder);
  this._logger.log(params.keys());
  return this.http.get(url,{params:params})
              .toPromise()
              .then(response => response as User[])
              .catch(this.handleError);
}

private handleError(error: any): Promise<any> {
  return Promise.reject(error.message || error);
}
}
