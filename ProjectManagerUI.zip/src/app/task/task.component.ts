import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { Task } from '../model/task';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { UsersearchComponent } from '../popup/usersearch/usersearch.component';
import { Logger } from '../utillity/logger.service';
import { DatePipe } from '@angular/common';
import { TaskService } from '../service/task.service';
import { ParentTask } from '../model/ParentTask';
import { ProjectsearchComponent } from '../popup/projectsearch/projectsearch.component';
import { TasksearchComponent } from '../popup/tasksearch/tasksearch.component';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  addTaskTab = true;
  viewTaskTab = true;
  isUpdate = false;
  isAdd = true;
  isSearchingTask = false;
  setParentTask = true;
  task :Task;
  taskList : Task[];
  datesValidated = false;

  taskForm = new FormGroup({
    taskName: new FormControl(''),
    priorityValue: new FormControl(''),
    setParentTask:new FormControl(''),
    startDate:new FormControl(''),
    endDate:new FormControl(''),
    userId:new FormControl(''),
    userName :new FormControl(''),
    projectId:new FormControl(''),
    projectTitle :new FormControl(''),
    parentTaskName:new FormControl(''),
    parentTaskId :new FormControl('')
  });
  
  @Input() taskEntity;

  @ViewChild(UsersearchComponent) searchUserModal :UsersearchComponent;
  @ViewChild(ProjectsearchComponent) searchProjectModal :ProjectsearchComponent;
  @ViewChild(TasksearchComponent) searchTaskModal :TasksearchComponent;

  constructor(private tab :NgbTabset,
    private _logger : Logger,
    private fb: FormBuilder,
   private taskService : TaskService,
   private datePipe: DatePipe) { }

  ngOnInit() {
    if(this.tab.activeId == 'viewTaskTabId'){
      this.viewTaskTab = true;
      this.addTaskTab = false;
      //this.getTasks();
    }else{
      this.viewTaskTab = false;
      this.addTaskTab = true;
      this._logger.log(this.taskEntity);
      if(this.taskEntity != null){
       
        this.task = this.taskEntity;
        
      
      }
      this.createForm();
      this.taskForm.controls['parentTaskName'].disable();
      this.taskForm.controls['userName'].disable();
      this.taskForm.controls['projectTitle'].disable();
      if(this.taskEntity != null){
        this.taskForm.controls['setParentTask'].disable();
        this.toggleButton();
      }
      
    }
    
  }

  private createForm() {
    let currentDate =new Date();
    if(this.task != null){
       let _temp = this.task;
        this.taskForm = this.fb.group({
            taskName: [_temp.taskName,Validators.required ],
            priorityValue: [_temp.priority, Validators.required],
            userId:[_temp.user != null?_temp.user.userId:'', Validators.required],
            parentTaskId :[_temp.parentTask != null ?_temp.parentTask.parentTaskId:''],
            parentTaskName :[_temp.parentTask != null ?_temp.parentTask.taskName:''],
            setParentTask:[_temp.parentTask != null ? true:false],
            startDate:[this.datePipe.transform(_temp.startDate,'yyyy-MM-dd'), Validators.required],
            endDate:[this.datePipe.transform(_temp.endDate,'yyyy-MM-dd'), Validators.required],
            userName:[_temp.user != null?_temp.user.firstName+' '+_temp.user.lastName:''],
            projectId:[_temp.project != null ? _temp.project.projectId:'', Validators.required],
            projectTitle :[_temp.project != null ? _temp.project.title:'']
        });
    }else{
      this.taskForm = this.fb.group({
        taskName: ['',Validators.required ],
            priorityValue: ['', Validators.required],
            userId:['', Validators.required],
            parentTaskId :[''],
            parentTaskName :[''],
            setParentTask:[false],
            startDate:[this.datePipe.transform(currentDate,'yyyy-MM-dd'), Validators.required],
            endDate:[this.datePipe.transform(currentDate.setDate(currentDate.getDate() + 1),'yyyy-MM-dd'), Validators.required],
            userName:[''],
            projectId:['', Validators.required],
            projectTitle :['']
      });
    }
  }

  //Adding new Task in the Application
  public addNewTask($event){
    console.log(this.taskForm.controls['taskName'].value);
    let task : Task;
    task = {
      'taskId' :null,
      'taskName':this.taskForm.controls['taskName'].value,
      'priority':this.taskForm.controls['priorityValue'].value,
      'userId':this.taskForm.controls['userId'].value,
      'startDate':this.taskForm.controls['startDate'].value !=null ?this.datePipe.transform(this.taskForm.controls["startDate"].value,'yyyy-MM-dd HH:mm:ss'):null,
      'endDate':this.taskForm.controls['endDate'].value !=null ?this.datePipe.transform(this.taskForm.controls["endDate"].value,'yyyy-MM-dd HH:mm:ss'):null,
      'isActive':true,
      'isParent':this.taskForm.controls['setParentTask'].value,
      'parentTaskId':this.taskForm.controls['parentTaskId'].value,
      'parentTask':null,
      'projectId':this.taskForm.controls['projectId'].value,
      'project':null,
      'user':null,
      'status':'Pending'
  };
  console.log(task);
  if(task.isParent){
    let parentTask :ParentTask;
    parentTask = {
      'taskName':this.taskForm.controls['taskName'].value,
      'parentTaskId':null
    }
    this.taskService.addParentTask(parentTask).then((res) => {
      this.taskForm.reset();
    })
  }else{
  this.taskService.addTask(task).then((res) => {
    this.taskForm.reset();
  })
}
  }

  //get all the Tasks details available in the application
  private getTasks(){
    this._logger.log("Calling get All Tasks");
    //this.spinner.show();
    return this.taskService.getTasks().then(tasks => 
        {
            this.taskList = tasks;
           // this.tableComp.getTasksView();
            //this.spinner.hide();
        },(error) => {
            this._logger.log(error);
            });
}

//reset project Form
public resetTaskForm($event){
  this.taskForm.reset();
    this.setParentTask = true;
    let currentDate =new Date();
    this.taskForm.controls['priorityValue'].enable();
    this.taskForm.controls['startDate'].enable();
    this.taskForm.controls['endDate'].enable();
    this.taskForm.controls['priorityValue'].setValidators([Validators.required]);
    this.taskForm.controls['startDate'].setValue(this.datePipe.transform(currentDate,'yyyy-MM-dd'));
    this.taskForm.controls['startDate'].setValidators([Validators.required]);
    this.taskForm.controls['endDate'].setValue(this.datePipe.transform(currentDate.setDate(currentDate.getDate() + 1),'yyyy-MM-dd'));
    this.taskForm.controls['endDate'].setValidators([Validators.required]);
    this.taskForm.controls['projectId'].setValidators([Validators.required]);
    this.taskForm.controls['userId'].setValidators([Validators.required]);
    

}
// Logic on set start and end date checkbox
public enableDisableParentTask(event : any){
if(this.taskForm.controls['setParentTask'].value){

  let currentDate = new Date();
    this.setParentTask = true;
    this.taskForm.controls['priorityValue'].enable();
    this.taskForm.controls['startDate'].enable();
    this.taskForm.controls['endDate'].enable();
    this.taskForm.controls['projectId'].enable();
    this.taskForm.controls['userId'].enable();
    this.taskForm.controls['priorityValue'].setValidators([Validators.required]);
    this.taskForm.controls['startDate'].setValue(this.datePipe.transform(currentDate,'yyyy-MM-dd'));
    this.taskForm.controls['startDate'].setValidators([Validators.required]);
    this.taskForm.controls['endDate'].setValue(this.datePipe.transform(currentDate.setDate(currentDate.getDate() + 1),'yyyy-MM-dd'));
    this.taskForm.controls['endDate'].setValidators([Validators.required]);
    this.taskForm.controls['projectId'].setValidators([Validators.required]);
    this.taskForm.controls['userId'].setValidators([Validators.required]);
    
}else{
  this.taskForm.controls['parentTaskName'].reset();
  this.taskForm.controls['parentTaskId'].reset();
  this.taskForm.controls['projectId'].reset();
  this.taskForm.controls['projectTitle'].reset();
  this.taskForm.controls['userName'].reset();
  this.taskForm.controls['userId'].reset();
  this.taskForm.controls['priorityValue'].reset();
  this.taskForm.controls['startDate'].reset();
  this.taskForm.controls['endDate'].reset();

  this.setParentTask = false;
  this.taskForm.controls['priorityValue'].disable();
  this.taskForm.controls['startDate'].disable();
  this.taskForm.controls['projectId'].disable();
  this.taskForm.controls['endDate'].disable();
  this.taskForm.controls['userId'].disable();

  this.error={isError:false,errorMessage:''};
  this.datesValidated = false;

  this._logger.log(this.taskForm.pristine+' '+this.taskForm.invalid +' '+ this.datesValidated);
}
}

//search Project Modal Popup
public openProjectSearch(valueHolder :string){
  this.searchProjectModal.openSearchProjectModal();
}

selectedprojecttitle ='' ;
selectedprojectId ='';
setSelectedProject(project:any){
  if(this.viewTaskTab){
    this.selectedprojecttitle = project.title;
    this.selectedprojectId = project.projectId;
    this.onSearchTask(project.projectId);
  }else{
    this._logger.log(project.managerName);
    this.taskForm.controls['projectTitle'].setValue(project.manager.firstName+' '+project.manager.lastName);
    this.taskForm.controls['projectId'].setValue(project.projectId);
    
    this._logger.log(this.taskForm.controls['projectId'].value);
  }
}

//search Task Modal Popup
public openTaskSearch(valueHolder :string){
  this.searchTaskModal.openSearchTaskModal();
}

setSelectedTask(parentTask:any){
  this._logger.log(parentTask.taskName);
  this.taskForm.controls['parentTaskName'].setValue(parentTask.taskName);
  this.taskForm.controls['parentTaskId'].setValue(parentTask.parentTaskId);
  this._logger.log(this.taskForm.controls['parentTaskId'].value);
}

//Search user Popup
public openUserSearch(valueHolder :string){
  this.searchUserModal.openSearchUserModal();
}

setSelectedUser(user:any){
  this._logger.log(user.firstName);
  this.taskForm.controls['userName'].setValue(user.firstName+' '+user.lastName);
  this.taskForm.controls['userId'].setValue(user.userId);
  this._logger.log(this.taskForm.controls['userId'].value);
}

@Output() saveSelectedTask: EventEmitter<any> = new EventEmitter();
//edit Task details
public editTaskDetails(item :any){
  this.saveSelectedTask.emit(item);
  this.tab.select('taskTabId');
}

//update Task details in database

public updateTaskDetails($event){

  let temp =new Task();
  temp = {
      'taskId' :this.task.taskId,
      'taskName':this.taskForm.controls['taskName'].value,
      'priority':this.taskForm.controls['priorityValue'].value,
      'projectId':this.taskForm.controls['projectId'].value,
      'project':null,
      'startDate':this.taskForm.controls['startDate'].value !=null ?this.datePipe.transform(this.taskForm.controls["startDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'endDate':this.taskForm.controls['endDate'].value !=null ?this.datePipe.transform(this.taskForm.controls["endDate"].value,'yyyy-MM-dd HH:mm:ss'):'',
      'userId':this.taskForm.controls['userId'].value,
      'user':null,
      'parentTaskId':this.taskForm.controls['parentTaskId'].value,
      'parentTask':null,
      'status':'Pending',
      'isParent':this.taskForm.controls['setParentTask'].value,
      'isActive':true
  };
  this._logger.log(temp);
  this.task = null;
  this.taskService.updateTaskDetails(temp).then((res) => { 
    //this.createForm();
    this.taskForm.reset();
   // this.getProjects();
    if(this.isUpdate)
      this.toggleButton();
    //this.spinner.hide(); // end loading 
    //this.popupHeading = "Addition Successfull!";
    //this.popupMessage = "Task has been added to my task list."
    //this.dialogContent.openFormModal(); //open successpopup
    //this.okClickCall({action:'OK'});
})
}

//Delete User
public endTask(task:any){
  this.taskService.endTask(task.taskId).then((res) => {
    this.onSearchTask(task.projectId);
})
}

//Searching Tasks View
public onSearchTask(id: any){
  let query = id;
  this.isSearchingTask = true;
  if(query != ''){
  this.taskService.searchTasks(query).then(tasks => 
    {
        this.taskList = tasks;
      // this.tableComp.getTasksView();
      //this.spinner.hide();
    },(error) => {
        this._logger.log(error);
        });
      }
}

//Sort Tasks List by selected project
sortOrder = 'DESC';
public sortTasks(sortBy :string){
    if(this.sortOrder == 'DESC'){
      this.sortOrder = 'ASC';
    }else{
      this.sortOrder = 'DESC';
    }
    this.taskService.sortProjectTasks({'projectId':this.selectedprojectId,'sortBy':sortBy,'sortOrder':this.sortOrder}).then(tasks => 
      {
          this.taskList = tasks;
        // this.tableComp.getTasksView();
        //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }


public cancelTaskUpdate($event){
  this.taskEntity = null;
  this.task = null;
  this.saveSelectedTask.emit(null);
  this.createForm();
  if(this.isUpdate)
      this.toggleButton();
}

private toggleButton() {
  this.isAdd = !this.isAdd;
  this.isUpdate = !this.isUpdate;
}

//Start and End dates validation
error:any={isError:false,errorMessage:''};
compareTwoDates(){
   if(new Date(this.taskForm.controls['endDate'].value) < new Date(this.taskForm.controls['startDate'].value)){
      this.error={isError:true,errorMessage:'End Date can not before start date'};
      this.datesValidated = true;
   }else{
    this.error={isError:false,errorMessage:''};
    this.datesValidated = false;
   }
}
}
