import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { User } from '../model/user';
import { UserService } from '../service/user.service';
import { Logger } from '../utillity/logger.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
 
  isUpdate = false;
  isAdd = true;
  isSearchingUser = false;
  user :User;
  userlist : User[];
  userForm = new FormGroup({
    fname: new FormControl(''),
    lname: new FormControl(''),
    empid:new FormControl('')
  });
  
  constructor(private _logger : Logger, private fb: FormBuilder, private userService: UserService) { }

  ngOnInit() {
    this.createForm();
    this.getUsers();
  }

  private createForm() {
    if(this.user != null){
       let _tempuser = this.user;
        this.userForm = this.fb.group({
            fname: [_tempuser.firstName,Validators.required ],
            lname: [_tempuser.lastName, Validators.required],
            empid:[_tempuser.empId, Validators.required]
        });
    }else{
      this.userForm = this.fb.group({
        fname: ['',Validators.required ],
        lname: ['', Validators.required],
        empid:['', Validators.required]
      });
    }
  }

  //Adding new User in the Application
  public addNewUser($event){
    console.log(this.userForm.controls['fname'].value);
    let user : User;
    user = {
      'userId' :null,
      'firstName':this.userForm.controls['fname'].value,
      'lastName':this.userForm.controls['lname'].value,
      'empId':this.userForm.controls['empid'].value
  };
  console.log(user);
    this.userService.addUser(user).then((res) => {
      this.userForm.reset();
      this.getUsers(); 
  })
  }

  //get all the users available in the application
  private getUsers(){
    this._logger.log("Calling get All Tasks");
    //this.spinner.show();
    return this.userService.getUsers().then(users => 
        {
            this.userlist = users;
           // this.tableComp.getTasksView();
            //this.spinner.hide();
        },(error) => {
            this._logger.log(error);
            });
}

//edit user details
public editUser(item :any){
  this._logger.log("calling edit form :"+item.firstName);
  this.user = item;
  this.createForm();
  if(!this.isUpdate)
    this.toggleButton();
    window.scrollTo({top:0,behavior: 'smooth'});
}

//update user details in database

public updateUser($event){

  let tempUser : User;
  tempUser = {
      'userId' :this.user.userId,
      'firstName':this.userForm.controls['fname'].value,
      'lastName':this.userForm.controls['lname'].value,
      'empId':this.userForm.controls['empid'].value
  };
  this._logger.log(tempUser);
  this.user = null;
  this.userService.updateUserDetails(tempUser).then((res) => { 
    //this.createForm();
    this.userForm.reset();
    this.getUsers(); 
    if(this.isUpdate)
      this.toggleButton();
    //this.spinner.hide(); // end loading 
    //this.popupHeading = "Addition Successfull!";
    //this.popupMessage = "Task has been added to my task list."
    //this.dialogContent.openFormModal(); //open successpopup
    //this.okClickCall({action:'OK'});
})
}

//Delete User
public deleteUser(id:any){
  this._logger.log("deleted now-->"+id);
  this.userService.deleteUser(id).then((res) => {
   
    this.getUsers(); 
})
}

//Searching User
public onSearch(event: any){
  this._logger.log('--Searching For ---:'+event.target.value);
  let query = event.target.value;
  this.isSearchingUser = true;
  this.userService.searchUsers(query).then(users => 
    {
        this.userlist = users;
      // this.tableComp.getTasksView();
      //this.spinner.hide();
    },(error) => {
        this._logger.log(error);
        });
}
//Sort User List by selected
sortOrder = 'DESC';
public sortUsers(sortBy :string){
    if(this.sortOrder == 'DESC'){
      this.sortOrder = 'ASC';
    }else{
      this.sortOrder = 'DESC';
    }
    this.userService.sortUsers({'sortBy':sortBy,'sortOrder':this.sortOrder}).then(users => 
      {
          this.userlist = users;
        // this.tableComp.getTasksView();
        //this.spinner.hide();
      },(error) => {
          this._logger.log(error);
          });
  }
public cancelUserUpdate($event){
  this.user = null;
  this.createForm();
  if(this.isUpdate)
      this.toggleButton();
}

private toggleButton() {
  this.isAdd = !this.isAdd;
  this.isUpdate = !this.isUpdate;
}
}
