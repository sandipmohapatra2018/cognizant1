package com.fsd.projectmanager;

import java.util.Collection;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fsd.projectmanager.model.ParentTask;
import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.ProjectView;
import com.fsd.projectmanager.model.Task;
import com.fsd.projectmanager.model.User;
import com.fsd.projectmanager.service.ProjectService;
import com.fsd.projectmanager.service.ProjectServiceImpl;
import com.fsd.projectmanager.service.TaskService;
import com.fsd.projectmanager.service.TaskServiceImpl;
import com.fsd.projectmanager.service.UserService;
import com.fsd.projectmanager.service.UserServiceImpl;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("users")
public class ProjectAppResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
	private static final UserService userService = (UserServiceImpl) StaticApplicationContext.getContext().getBean("userService");
	private static final ProjectService projectService = (ProjectServiceImpl) StaticApplicationContext.getContext().getBean("projectService");
	private static final TaskService taskService = (TaskServiceImpl) StaticApplicationContext.getContext().getBean("taskService");
	private static final Logger logger = LoggerFactory.getLogger(ProjectAppResource.class);
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<User> getUsers(@QueryParam(value="sortBy") String sortBy, @QueryParam(value="sortOrder") String sortOrder){
		logger.debug("Fetching all task list--->");
			return userService.getUsers(sortBy,sortOrder);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User createUser(User user) {
		
		logger.debug("Add user is called : "+user.getFirstName());
		user.setCreatedDate(new Date());
		User tempUser = userService.addUser(user);
		return tempUser;
	}
	
	@PUT
	@Path("/{userId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User updateUserDetails(@PathParam("userId") Long userId, User user) {
		user.setModifiedDate(new Date());
		user.setUserId(userId);
		User rtnObj = userService.updateUserDetails(user);
		return rtnObj;
	}
	
	@DELETE
	@Path("/{userId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User deleteUser(@PathParam("userId") Long userId) {
		logger.debug("Calling delete Task end task....");
		User retUser = userService.deleteUser(userId);
		return retUser;
	}
	
	@GET
	@Path("/search/{values}")
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<User> searchUsers(@PathParam("values") String queryString){
		logger.debug("Fetching all task list--->");
		if(userService.getUsers(null,null).size() == 0)
			return null;
		else if(queryString != null && !queryString.isEmpty())
			return userService.searchUsers(queryString);
		else
			return userService.getUsers(null,null);
	}
	
	/*
	 * Tasks Method to serve RESTFull API
	 * */
	@Path("/tasks")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task createTask(Task task) {
		
		logger.debug("Add user is called : "+task.getTaskName());
		Task tempObj = taskService.addTask(task);
		return tempObj;
	}
	//parent Task Search and Update in database
	@Path("/tasks/parenttask")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public ParentTask createParentTask(ParentTask task) {
		
		logger.debug("Add user is called : "+task.getTaskName());
		ParentTask tempObj = taskService.addParentTask(task);
		return tempObj;
	}
	
	@Path("/tasks/parenttask")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<ParentTask> getAllParentTasks(@QueryParam(value="sortBy") String sortBy, @QueryParam(value="sortOrder") String sortOrder) {
		return taskService.getParentTasks(sortBy, sortOrder);
	}
	
	@GET
	@Path("/tasks/parenttask/search/{values}")
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<ParentTask> searchParentTasks(@PathParam("values") String queryString){
		logger.debug("Fetching all Project list--->");
		if(queryString != null && !queryString.isEmpty())
			return taskService.searchParentTasks(queryString);
		else
			return taskService.getParentTasks(null,null);
	}
	//Parent Task Ended
	
	@Path("/tasks")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<Task> getAllTasks(@QueryParam(value="sortBy") String sortBy, @QueryParam(value="sortOrder") String sortOrder) {
		return taskService.getTasks(sortBy, sortOrder);
	}
	
	@PUT
	@Path("/tasks/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task updateTaskDetails(@PathParam("taskId") Long taskId, Task task) {
		task.setModifiedDate(new Date());
		task.setTaskId(taskId);
		Task rtnObj = taskService.updateTaskDetails(task);
		return rtnObj;
	}
	
	@DELETE
	@Path("/tasks/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task completeTask(@PathParam("taskId") Long taskId) {
		Task retObj = taskService.deleteTask(taskId);
		return retObj;
	}
	
	@GET
	@Path("/tasks/search/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<Task> searchTasks(@PathParam("id") Long id,@QueryParam(value="sortBy") String sortBy, @QueryParam(value="sortOrder") String sortOrder){
		logger.debug("Fetching all Project list--->");
			return taskService.searchTasks(id,sortBy, sortOrder);
	}
	
	/*
	 * Projects Method to serve RESTFull API
	 * */
	@Path("/projects")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Project createProject(Project project) {
		
		logger.debug("Add user is called : "+project.getTitle());
		Project tempObj = projectService.addProject(project);
		return tempObj;
	}
	
	@Path("/projects")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<ProjectView> getAllProjects(@QueryParam(value="sortBy") String sortBy, @QueryParam(value="sortOrder") String sortOrder) {
		return projectService.getProjects(sortBy, sortOrder);
	}
	
	@PUT
	@Path("/projects/{projectId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Project updateProjectDetails(@PathParam("projectId") Long projectId, Project project) {
		project.setModifiedDate(new Date());
		project.setProjectId(projectId);
		Project rtnObj = projectService.updateProjectDetails(project);
		return rtnObj;
	}
	
	@DELETE
	@Path("/projects/{projectId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Project deleteProject(@PathParam("projectId") Long projectId) {
		Project retObj = projectService.deleteProject(projectId);
		return retObj;
	}
	
	@GET
	@Path("/projects/search/{values}")
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<ProjectView> searchProjects(@PathParam("values") String queryString){
		logger.debug("Fetching all Project list--->");
		if(queryString != null && !queryString.isEmpty())
			return projectService.searchProjects(queryString);
		else
			return projectService.getProjects(null,null);
	}
	
}
