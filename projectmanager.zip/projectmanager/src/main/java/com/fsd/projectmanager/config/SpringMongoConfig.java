package com.fsd.projectmanager.config;

import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.fsd.projectmanager.repository.UserRepository;
import com.fsd.projectmanager.repository.UserRepositoryImpl;
import com.mongodb.MongoClient;

public class SpringMongoConfig {
  
	public @Bean
	MongoDbFactory mongoDbFactory() throws Exception {
		return new SimpleMongoDbFactory(new MongoClient(), "projectManagerDB");
	}

	public @Bean
	MongoTemplate mongoTemplate() throws Exception {
		
		MongoTemplate mongoTemplate = new MongoTemplate(mongoDbFactory());
				
		return mongoTemplate;
		
	}
	
	public @Bean
	UserRepository UserRepository() throws Exception{
		UserRepository userRepo = new UserRepositoryImpl();
		return userRepo;
	}
}
