package com.fsd.projectmanager.model;

import java.util.Date;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProjectView implements Comparable {

	private Long projectId;
	private String title;
	private int priority;
	private User manager ;
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date endDate;
	private int noOfTasks;
	private int completed;
	private boolean isActive;
	private String sortOrder;
	
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public User getManager() {
		return manager;
	}
	public void setManager(User manager) {
		this.manager = manager;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getNoOfTasks() {
		return noOfTasks;
	}
	public void setNoOfTasks(int noOfTasks) {
		this.noOfTasks = noOfTasks;
	}
	
	public int getCompleted() {
		return completed;
	}
	public void setCompleted(int completed) {
		this.completed = completed;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	@Override
	public int compareTo(Object o) {
		ProjectView pObj = (ProjectView)o;
		int compare = pObj.getCompleted();
		return compare - this.getCompleted();
	}
}
