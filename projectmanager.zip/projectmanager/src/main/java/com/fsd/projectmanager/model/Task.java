package com.fsd.projectmanager.model;


import java.util.Date;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author 427629
 *
 */

@XmlRootElement
@Document(collection="task_")
public class Task {

	@Id
	private Long taskId;
	
	@Field
	private Long projectId;
	
	@DBRef
	private Project project;
	
	@Field
	private Long parentTaskId;
	
	@DBRef
	private ParentTask parentTask;
	
	@Field
	private Long userId;
	
	@DBRef
	private User user;
	
	private String taskName;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date endDate;
	private int priority;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date createdDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
	
	@Field
	private Boolean isActive =  true;
	
	@Field
	boolean isParent = false;
	
	@Field
	private String status;
	

	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	public boolean isParent() {
		return isParent;
	}




	public void setParent(boolean isParent) {
		this.isParent = isParent;
	}




	/**
	 * @return the taskId
	 */
	public Long getTaskId() {
		return taskId;
	}




	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}




	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}




	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}




	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}




	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}




	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}




	/**
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}




	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}




	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}




	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}




	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}




	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}




	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}






	public Long getProjectId() {
		return projectId;
	}




	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}




	public Project getProject() {
		return project;
	}




	public void setProject(Project project) {
		this.project = project;
	}




	public Long getUserId() {
		return userId;
	}




	public void setUserId(Long userId) {
		this.userId = userId;
	}




	public User getUser() {
		return user;
	}




	public void setUser(User user) {
		this.user = user;
	}




	public Long getParentTaskId() {
		return parentTaskId;
	}




	public void setParentTaskId(Long parentTaskId) {
		this.parentTaskId = parentTaskId;
	}




	public ParentTask getParentTask() {
		return parentTask;
	}




	public void setParentTask(ParentTask parentTask) {
		this.parentTask = parentTask;
	}

	

}
