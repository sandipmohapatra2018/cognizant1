package com.fsd.projectmanager.model;


import java.util.Date;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author 427629
 *
 */

@XmlRootElement
@Document(collection="user_")
public class User {

	@Id
	private Long userId;
	
	@Field
	private String firstName;
	
	@Field
	private String lastName;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date createdDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
	
	@Field
	private Boolean isActive =  true;
	
	@Field
	private String empId;
	
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", createdDate="
				+ createdDate + ", modifiedDate=" + modifiedDate + ", isActive=" + isActive + ", empId=" + empId + "]";
	}

	
}
