package com.fsd.projectmanager.repository;

import java.util.Collection;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.fsd.projectmanager.model.ParentTask;

public interface ParentTaskRepository extends MongoRepository<ParentTask, String>{

	Collection<ParentTask> searchParentTasks(String queryString);

}
