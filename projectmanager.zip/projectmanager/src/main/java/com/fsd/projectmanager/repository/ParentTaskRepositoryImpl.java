package com.fsd.projectmanager.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.fsd.projectmanager.model.ParentTask;

@Repository
public class ParentTaskRepositoryImpl implements ParentTaskRepository {

	@Autowired
	private MongoOperations mongoOperation;
	
	@Override
	public <S extends ParentTask> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ParentTask> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ParentTask> findAll(Sort sort) {
		Query searchUserQuery = new Query();
		searchUserQuery.with(sort);
		return mongoOperation.find(searchUserQuery, ParentTask.class);
	}

	@Override
	public <S extends ParentTask> S insert(S entity) {
		S savedEntity = null;
		try {
		mongoOperation.save(entity);
		Query searchUserQuery = new Query(Criteria.where("parentTaskId").is(entity.getParentTaskId()));
		savedEntity = (S)mongoOperation.findOne(searchUserQuery, ParentTask.class);
		}catch(Exception e) {
			System.out.println(e.getClass() +" ---------"+e.getMessage());
		}
		return savedEntity;
	}

	@Override
	public <S extends ParentTask> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<ParentTask> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ParentTask> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<ParentTask> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(ParentTask entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends ParentTask> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends ParentTask> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends ParentTask> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Collection<ParentTask> searchParentTasks(String queryString) {
		Query searchUserQuery = new Query(Criteria.where("taskName").regex(queryString.toString(), "i"));
		return mongoOperation.find(searchUserQuery, ParentTask.class);
	}

}
