package com.fsd.projectmanager.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.ProjectView;

public interface ProjectRepository  extends MongoRepository<Project, String>{

	Project findById(Long projectId);

	Collection<ProjectView> searchProjects(String queryString);

	List<ProjectView> findAllView(Sort sort);

}
