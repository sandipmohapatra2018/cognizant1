package com.fsd.projectmanager.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.ProjectView;
import com.fsd.projectmanager.model.Task;
import com.fsd.projectmanager.model.User;

@Repository
public class ProjectRepositoryImpl implements ProjectRepository {

	@Autowired
	private MongoOperations mongoOperation;
	
	@Override
	public <S extends Project> List<S> saveAll(Iterable<S> entites) {
		return null;
	}

	@Override
	public List<Project> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Project> findAll(Sort sort) {
		Query searchUserQuery = new Query(Criteria.where("isActive").is(true));
		searchUserQuery.with(sort);
		return mongoOperation.find(searchUserQuery, Project.class);
	}

	@Override
	public List<ProjectView> findAllView(Sort sort) {
		List<ProjectView> viewList = null;
		ProjectView view =null;
		Query searchUserQuery = new Query(Criteria.where("isActive").is(true)).with(sort);
		List<Project> projectList = mongoOperation.find(searchUserQuery, Project.class);
		if(projectList != null && projectList.size() > 0) {
			List<Task> taskList = null;
			viewList = new ArrayList<ProjectView>();
			for(Project project :projectList) {
				view = new ProjectView();
				view.setProjectId(project.getProjectId());
				view.setTitle(project.getTitle());
				view.setPriority(project.getPriority());
				view.setEndDate(project.getEndDate());
				view.setStartDate(project.getStartDate());
				view.setManager(project.getManager());
				
				searchUserQuery = new Query(new Criteria()
						.andOperator(Criteria.where("isActive").is(true),Criteria.where("projectId").is(project.getProjectId())));
				taskList = mongoOperation.find(searchUserQuery, Task.class);
				if(taskList != null)
					view.setNoOfTasks(taskList.size());
				searchUserQuery = new Query(new Criteria()
						.andOperator(Criteria.where("status").is("Completed"),Criteria.where("projectId").is(project.getProjectId())));
				taskList = mongoOperation.find(searchUserQuery, Task.class);
				if(taskList != null)
					view.setCompleted(taskList.size());
				viewList.add(view);
			}
		}
		
		return viewList;
	}
	@Override
	public <S extends Project> S insert(S entity) {
		S savedProject = null;
		try {
		mongoOperation.save(entity);
		Query searchUserQuery = new Query(Criteria.where("projectId").is(entity.getProjectId()));
		savedProject = (S)mongoOperation.findOne(searchUserQuery, Project.class);
		}catch(Exception e) {
			System.out.println(e.getClass() +" ---------"+e.getMessage());
		}
		return savedProject;
	}

	@Override
	public <S extends Project> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Project> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Project> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Project> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Project> S save(S entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("projectId").is(entity.getProjectId()));
		Update update = new Update();
		update.set("title", entity.getTitle());
		update.set("startDate", entity.getStartDate());
		update.set("endDate", entity.getEndDate());
		update.set("priority", entity.getPriority());
		update.set("managerId", entity.getManagerId());
		Project retProject = mongoOperation.findAndModify(query, update, Project.class);
		return (S) retProject;
	}

	@Override
	public Optional<Project> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Project> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Project entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("projectId").is(entity.getProjectId()));
		Update update = new Update();
		update.set("isActive", false);
		mongoOperation.findAndModify(query, update, Project.class);
		
	}

	@Override
	public void deleteAll(Iterable<? extends Project> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Project> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Project> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Project> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Project> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Project findById(Long projectId) {
		Query searchUserQuery = new Query(Criteria.where("projectId").is(projectId));
		Project project = mongoOperation.findOne(searchUserQuery, Project.class);
		return project;
	}

	@Override
	public Collection<ProjectView> searchProjects(String queryString) {
		List<ProjectView> viewList = null;
		ProjectView view =null;
		Query searchUserQuery = new Query(new Criteria()
				.andOperator(Criteria.where("isActive").is(true),Criteria.where("title").regex(queryString.toString(), "i")));
		List<Project> projectList = mongoOperation.find(searchUserQuery, Project.class);
		if(projectList != null && projectList.size() > 0) {
			List<Task> taskList = null;
			viewList = new ArrayList<ProjectView>();
			for(Project project :projectList) {
				view = new ProjectView();
				view.setProjectId(project.getProjectId());
				view.setTitle(project.getTitle());
				view.setPriority(project.getPriority());
				view.setEndDate(project.getEndDate());
				view.setStartDate(project.getStartDate());
				view.setManager(project.getManager());
				
				searchUserQuery = new Query(new Criteria()
						.andOperator(Criteria.where("isActive").is(true),Criteria.where("projectId").is(project.getProjectId())));
				taskList = mongoOperation.find(searchUserQuery, Task.class);
				if(taskList != null)
					view.setNoOfTasks(taskList.size());
				searchUserQuery = new Query(new Criteria()
						.andOperator(Criteria.where("status").is("Completed"),Criteria.where("projectId").is(project.getProjectId())));
				taskList = mongoOperation.find(searchUserQuery, Task.class);
				if(taskList != null)
					view.setCompleted(taskList.size());
				viewList.add(view);
			}
		}
		
		return viewList;
	}

}
