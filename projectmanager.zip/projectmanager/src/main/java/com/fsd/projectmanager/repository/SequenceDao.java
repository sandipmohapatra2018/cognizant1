package com.fsd.projectmanager.repository;

import com.fsd.projectmanager.exception.SequenceException;

public interface SequenceDao {

	long getNextSequenceId(String key) throws SequenceException;
}
