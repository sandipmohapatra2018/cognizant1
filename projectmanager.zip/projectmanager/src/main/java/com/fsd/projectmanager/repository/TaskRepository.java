package com.fsd.projectmanager.repository;

import java.util.Collection;

import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.fsd.projectmanager.model.Task;

public interface TaskRepository  extends MongoRepository<Task, String>{

	Collection<Task> searchTasks(Long queryString, Sort sort);

	Task findById(Long taskId);

	

}
