package com.fsd.projectmanager.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.fsd.projectmanager.model.Task;

@Repository
public class TaskRepositoryImpl implements TaskRepository {

	@Autowired
	private MongoOperations mongoOperation;
	
	@Override
	public <S extends Task> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Task> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Task> findAll(Sort sort) {
		Query searchUserQuery = new Query(Criteria.where("isActive").is(true));
		searchUserQuery.with(sort);
		return mongoOperation.find(searchUserQuery, Task.class);
	}

	@Override
	public <S extends Task> S insert(S entity) {
		S savedEntity = null;
		try {
		mongoOperation.save(entity);
		Query searchUserQuery = new Query(Criteria.where("taskId").is(entity.getTaskId()));
		savedEntity = (S)mongoOperation.findOne(searchUserQuery, Task.class);
		}catch(Exception e) {
			System.out.println(e.getClass() +" ---------"+e.getMessage());
		}
		return savedEntity;
	}

	@Override
	public <S extends Task> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Task> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Task> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Task> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Task> S save(S entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("taskId").is(entity.getTaskId()));
		Update update = new Update();
		update.set("taskName", entity.getTaskName());
		update.set("startDate", entity.getStartDate());
		update.set("endDate", entity.getEndDate());
		update.set("priority", entity.getPriority());
		update.set("userId", entity.getUserId());
		update.set("parentTaskId", entity.getParentTaskId());
		update.set("parentTask", entity.getParentTask());
		Task retObj = mongoOperation.findAndModify(query, update, Task.class);
		return (S) retObj;
	}

	@Override
	public Optional<Task> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Task> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Task entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("taskId").is(entity.getTaskId()));
		Update update = new Update();
		update.set("status", "Completed");
		mongoOperation.findAndModify(query, update, Task.class);
		
	}

	@Override
	public void deleteAll(Iterable<? extends Task> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Task> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Task> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Task> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Task> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Collection<Task> searchTasks(Long queryString,Sort sort) {
			Collection<Task> taskList_temp = null;
			Query searchUserQuery = new Query(new Criteria()
					.andOperator(Criteria.where("isActive").is(true),Criteria.where("projectId").is(queryString))).with(sort);
			taskList_temp=mongoOperation.find(searchUserQuery, Task.class);
			return taskList_temp;
	}

	@Override
	public Task findById(Long taskId) {
		// TODO Auto-generated method stub
		return mongoOperation.findById(taskId, Task.class);
	}

}
