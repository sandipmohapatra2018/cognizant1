package com.fsd.projectmanager.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.fsd.projectmanager.model.User;

public interface UserRepository extends MongoRepository<User, String>{

	User findById(Long id);

	List<User> serachUsers(String querySting);
}
