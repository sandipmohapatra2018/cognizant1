package com.fsd.projectmanager.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.fsd.projectmanager.model.User;

@Repository
public class UserRepositoryImpl implements UserRepository{

	@Autowired
	private MongoOperations mongoOperation;
	
	@Override
	public <S extends User> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> findAll() {
		Query searchUserQuery = new Query(Criteria.where("isActive").is(true));
		return mongoOperation.find(searchUserQuery, User.class);
	}

	@Override
	public List<User> findAll(Sort sort) {
		Query searchUserQuery = new Query(Criteria.where("isActive").is(true));
		searchUserQuery.with(sort);
		return mongoOperation.find(searchUserQuery, User.class);
	}

	@Override
	public <S extends User> S insert(S entity) {
		S savedTask = null;
		try {
		mongoOperation.save(entity);
		Query searchUserQuery = new Query(Criteria.where("userId").is(entity.getUserId()));
		savedTask = (S)mongoOperation.findOne(searchUserQuery, User.class);
		}catch(Exception e) {
			System.out.println(e.getClass() +" ---------"+e.getMessage());
		}
		return savedTask;
	}

	@Override
	public <S extends User> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends User> List<S> findAll(Example<S> entity) {
		return null;
		
	}

	@Override
	public List<User> serachUsers(String querySting){
		Query searchUserQuery = new Query(new Criteria()
				.andOperator(Criteria.where("isActive").is(true), new Criteria().orOperator(Criteria.where("firstName").regex(querySting.toString(), "i"),
						Criteria.where("lastName").regex(querySting.toString(), "i"))));
		return mongoOperation.find(searchUserQuery, User.class);
	}
	@Override
	public <S extends User> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<User> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends User> S save(S entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("userId").is(entity.getUserId()));
		Update update = new Update();
		update.set("firstName", entity.getFirstName());
		update.set("lastName", entity.getLastName());
		update.set("modifiedDate", new Date());
		update.set("empId", entity.getEmpId());
		User retUser = mongoOperation.findAndModify(query, update, User.class);
		return (S) retUser;
	}

	@Override
	public Optional<User> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<User> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User entity) {
		Query query = new Query();
		query.addCriteria(Criteria.where("userId").is(entity.getUserId()));
		Update update = new Update();
		update.set("firstName", entity.getFirstName());
		update.set("lastName", entity.getLastName());
		update.set("modifiedDate", new Date());
		update.set("isActive", false);
		mongoOperation.findAndModify(query, update, User.class);
	}

	@Override
	public void deleteAll(Iterable<? extends User> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		//mongoOperation.remove
		
	}

	@Override
	public <S extends User> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends User> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends User> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends User> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User findById(Long id) {
		Query searchUserQuery = new Query(Criteria.where("userId").is(id));
		User user = mongoOperation.findOne(searchUserQuery, User.class);
		return user;
	}
	
	
}
