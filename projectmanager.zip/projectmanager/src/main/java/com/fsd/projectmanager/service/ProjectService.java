package com.fsd.projectmanager.service;

import java.util.Collection;

import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.ProjectView;

public interface ProjectService {

	Project addProject(Project project);

	Collection<ProjectView> getProjects(String sortBy, String orderBy);

	Project updateProjectDetails(Project project);

	Project deleteProject(Long projectId);

	Collection<ProjectView> searchProjects(String queryString);

}
