package com.fsd.projectmanager.service;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.ProjectView;
import com.fsd.projectmanager.model.User;
import com.fsd.projectmanager.repository.ProjectRepository;
import com.fsd.projectmanager.repository.SequenceDao;

@Service
public class ProjectServiceImpl implements ProjectService {

private static final String PROJ_SEQ_KEY = "project_.projectId";
	
	@Autowired
	private SequenceDao sequenceRepo;
	
	@Autowired
	private ProjectRepository projectRepo;
	
	
	@Override
	public Project addProject(Project project) {
		Project tempObj = null;
		project.setProjectId(sequenceRepo.getNextSequenceId(PROJ_SEQ_KEY));
		project.setCreatedDate(new Date());
		project.setIsActive(true);
		if(project.getManagerId() != null) {
			User userObj = new User();
			userObj.setUserId(project.getManagerId());
			project.setManager(userObj);
		}
		tempObj = projectRepo.insert(project);
		return tempObj;
	}

	
	@Override
	public Collection<ProjectView> getProjects(String sortBy, String orderBy) {
		Sort sort = null;
		if(sortBy != null && !sortBy.isEmpty() && orderBy != null && !orderBy.isEmpty()) {
			if(orderBy.equalsIgnoreCase("DESC"))
				sort = new Sort(Direction.DESC, sortBy);
			else
				sort = new Sort(Direction.ASC, sortBy);
		}else {
			sort = new Sort(Direction.DESC, "createdDate");
		}
		List<ProjectView> viewList= projectRepo.findAllView(sort);
		if(sortBy != null && sortBy.equalsIgnoreCase("completed")) {
			Collections.sort(viewList);
		}
		return viewList;
	}


	@Override
	public Project updateProjectDetails(Project project) {
		Project obj = projectRepo.save(project);
		return obj;
	}


	@Override
	public Project deleteProject(Long projectId) {
		Project project = getProject(projectId);
		project.setIsActive(false);
		projectRepo.delete(project);
		return null;
	}


	@Override
	public Collection<ProjectView> searchProjects(String queryString) {
		return projectRepo.searchProjects(queryString);
	}
	
	public Project getProject(Long projectId) {
		return projectRepo.findById(projectId);
	}
}
