package com.fsd.projectmanager.service;

import java.util.Collection;

import com.fsd.projectmanager.model.ParentTask;
import com.fsd.projectmanager.model.Task;

public interface TaskService {

	Task addTask(Task task);

	Collection<Task> getTasks(String sortBy, String sortOrder);

	Task updateTaskDetails(Task task);

	Task deleteTask(Long taskId);

	Collection<Task> searchTasks(Long id, String sortBy, String sortOrder);

	ParentTask addParentTask(ParentTask task);

	Collection<ParentTask> getParentTasks(String sortBy, String sortOrder);

	Collection<ParentTask> searchParentTasks(String queryString);

}
