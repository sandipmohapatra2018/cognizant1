package com.fsd.projectmanager.service;

import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.fsd.projectmanager.model.ParentTask;
import com.fsd.projectmanager.model.Project;
import com.fsd.projectmanager.model.Task;
import com.fsd.projectmanager.model.User;
import com.fsd.projectmanager.repository.ParentTaskRepository;
import com.fsd.projectmanager.repository.SequenceDao;
import com.fsd.projectmanager.repository.TaskRepository;

@Service
public class TaskServiceImpl implements TaskService {

private static final String TASK_SEQ_KEY = "task_.taskId";
private static final String PARENTTASK_SEQ_KEY = "parentTask_.parentTaskId";
	
	@Autowired
	private SequenceDao sequenceRepo;
	
	@Autowired
	private TaskRepository taskRepo;
	
	@Autowired
	private ParentTaskRepository parentTaskRepo;
	
	@Override
	public Task addTask(Task task) {
		Task tempObj = null;
			task.setTaskId(sequenceRepo.getNextSequenceId(TASK_SEQ_KEY));
			task.setCreatedDate(new Date());
			task.setIsActive(true);
			if(task.getUserId() != null) {
				User userObj = new User();
				userObj.setUserId(task.getUserId());
				task.setUser(userObj);
			}
			if(task.getProjectId() != null) {
				Project projObj = new Project();
				projObj.setProjectId(task.getProjectId());
				task.setProject(projObj);
			}
			if(task.getParentTaskId() != null) {
				ParentTask obj = new ParentTask();
				obj.setParentTaskId(task.getParentTaskId());
				task.setParentTask(obj);
			}
			tempObj = taskRepo.insert(task);
		return tempObj;
	}

	@Override
	public Collection<Task> getTasks(String sortBy, String orderBy) {
		Sort sort = null;
		if(sortBy != null && !sortBy.isEmpty() && orderBy != null && !orderBy.isEmpty()) {
			if(orderBy.equalsIgnoreCase("DESC"))
				sort = new Sort(Direction.DESC, sortBy);
			else
				sort = new Sort(Direction.ASC, sortBy);
		}else {
			sort = new Sort(Direction.DESC, "createdDate");
		}
		
		return taskRepo.findAll(sort);
	}

	@Override
	public Task updateTaskDetails(Task task) {
		
		if(task.getParentTaskId() != null) {
			ParentTask obj = new ParentTask();
			obj.setParentTaskId(task.getParentTaskId());
			task.setParentTask(obj);
		}
		
		Task obj = taskRepo.save(task);
		return obj;
	}

	@Override
	public Task deleteTask(Long taskId) {
		Task task = getTask(taskId);
		task.setStatus("Completed");
		taskRepo.delete(task);
		return null;
	}

	private Task getTask(Long taskId) {
		// TODO Auto-generated method stub
		return taskRepo.findById(taskId);
	}

	@Override
	public Collection<Task> searchTasks(Long queryString,String sortBy, String orderBy) {
		
		Sort sort = null;
		if(sortBy != null && !sortBy.isEmpty() && orderBy != null && !orderBy.isEmpty()) {
			if(orderBy.equalsIgnoreCase("DESC"))
				sort = new Sort(Direction.DESC, sortBy);
			else
				sort = new Sort(Direction.ASC, sortBy);
		}else {
			sort = new Sort(Direction.DESC, "createdDate");
		}
		
		return taskRepo.searchTasks(queryString,sort);
	}

	@Override
	public ParentTask addParentTask(ParentTask task) {
			ParentTask obj = new ParentTask();
			obj.setParentTaskId(sequenceRepo.getNextSequenceId(PARENTTASK_SEQ_KEY));
			obj.setTaskName(task.getTaskName());
			return parentTaskRepo.insert(obj);
	}

	@Override
	public Collection<ParentTask> getParentTasks(String sortBy, String sortOrder) {
		Sort sort = null;
		if(sortBy != null && !sortBy.isEmpty() && sortOrder != null && !sortOrder.isEmpty()) {
			if(sortOrder.equalsIgnoreCase("DESC"))
				sort = new Sort(Direction.DESC, sortBy);
			else
				sort = new Sort(Direction.ASC, sortBy);
		}else {
			sort = new Sort(Direction.DESC, "createdDate");
		}
		
		return parentTaskRepo.findAll(sort);
	}

	@Override
	public Collection<ParentTask> searchParentTasks(String queryString) {
		return parentTaskRepo.searchParentTasks(queryString);
	}

}
