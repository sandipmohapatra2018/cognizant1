package com.fsd.projectmanager.service;

import java.util.Collection;

import com.fsd.projectmanager.model.User;

public interface UserService {

	User addUser(User user);

	Collection<User> getUsers(String sortBy, String sortOrder);

	User updateUserDetails(User user);

	User deleteUser(Long userId);

	Collection<User> searchUsers(String queryString);
}
