package com.fsd.projectmanager.service;


import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.fsd.projectmanager.model.User;
import com.fsd.projectmanager.repository.SequenceDao;
import com.fsd.projectmanager.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	private static final String USER_SEQ_KEY = "user_.userId";
	
	@Autowired
	private SequenceDao sequenceRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	
	@Override
	public User addUser(User user) {
		User tempUser = null;
		user.setUserId(sequenceRepo.getNextSequenceId(USER_SEQ_KEY));
		user.setCreatedDate(new Date());
		user.setIsActive(true);
		tempUser = userRepo.insert(user);
		return tempUser;
	}


	@Override
	public Collection<User> getUsers(String sortBy, String orderBy) {
		Sort sort = null;
		if(sortBy != null && !sortBy.isEmpty() && orderBy != null && !orderBy.isEmpty()) {
			if(orderBy.equalsIgnoreCase("DESC"))
				sort = new Sort(Direction.DESC, sortBy);
			else
				sort = new Sort(Direction.ASC, sortBy);
		}else {
			sort = new Sort(Direction.DESC, "createdDate");
		}
		
		return userRepo.findAll(sort);
	}


	@Override
	public User updateUserDetails(User user) {
		User retUser = userRepo.save(user);
		return retUser;
	}


	@Override
	public User deleteUser(Long userId) {
		User user = getUser(userId);
		user.setIsActive(false);
		userRepo.delete(user);
		return null;
	}
	
	public User getUser(Long userId) {
			return userRepo.findById(userId);
		}


	@Override
	public Collection<User> searchUsers(String queryString) {
		return userRepo.serachUsers(queryString);
	}
}
