package com.fsd.projectmanager;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProjectAppResourceTest {

	@Test
	public void testGetUsers() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateUser() {
		fail("Not yet implemented");
	}

}
