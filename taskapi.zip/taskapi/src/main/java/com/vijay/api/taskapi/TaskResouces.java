package com.vijay.api.taskapi;

import java.util.Collection;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vijay.api.taskapi.model.Task;
import com.vijay.api.taskapi.service.TaskService;
import com.vijay.api.taskapi.service.TaskServiceImpl;

@Path("/tasks")
public class TaskResouces {

	private static final TaskService taskService = (TaskServiceImpl) StaticApplicationContext.getContext().getBean("taskService");
	private static final Logger logger = LoggerFactory.getLogger(TaskResouces.class);
	@GET
	@Path("/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Task getTask(@PathParam("taskId") Long id){
		return taskService.getTask(id);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Collection<Task> getTasks(){
		logger.debug("Fetching all task list--->");
		if(taskService.getTasks().size() == 0)
			return null;
		else
			return taskService.getTasks();
	}
	
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task createTask(Task task) {
		
		logger.debug("Task Creation Called : "+task.getTaskName());
		task.setCreatedDate(new Date());
		Task rtnTask = taskService.createTask(task);
		return rtnTask;
	}
	
	@PUT
	@Path("/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task updateTask(@PathParam("taskId") Long taskId, Task task) {
		task.setModifiedDate(new Date());
		task.setTaskId(taskId);
		Task rtnTask = taskService.updateTask(task);
		return rtnTask;
	}
	
	@DELETE
	@Path("/{taskId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Task removeTask(@PathParam("taskId") Long taskId) {
		logger.debug("Calling delete Task end task....");
		Task retTask = taskService.removeTask(taskId);
		return retTask;
	}
}
