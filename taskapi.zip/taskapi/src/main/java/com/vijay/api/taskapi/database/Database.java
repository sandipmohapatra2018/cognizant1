package com.vijay.api.taskapi.database;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.vijay.api.taskapi.config.SpringMongoConfig;
import com.vijay.api.taskapi.model.ParentTask;
import com.vijay.api.taskapi.model.SequenceGenerator;
import com.vijay.api.taskapi.model.Task;

public class Database {

	public static void main(String[] args) {
		 ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringMongoConfig.class);
		 MongoOperations mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
		 SequenceGenerator obj = new SequenceGenerator();
		 obj.setCounter(1l);
		 obj.setId("tbl_task.taskid");
		// mongoOperation.save(obj);
		 obj.setCounter(101l);
		 obj.setId("tbl_parenttask.parentid");
		 mongoOperation.save(obj);
		// Query searchUserQuery = new Query(Criteria.where("parentId").is(101l));
		/* ParentTask obj2 = new ParentTask();
		 obj2.setParentId(101l);
		 obj2.setParentTaskName("Parenet Task");
		 Task task =new Task();
		 task.setTaskId(1l);
		 task.setTaskName("First Task");
		 task.setParentTask(obj2);
		 task.setStartDate(new Date());
		 task.setEndDate(null);
		 task.setCreatedDate(new Date());
		 mongoOperation.save(obj2);
		 mongoOperation.save(task);
		 Query searchUserQuery = new Query(Criteria.where("parentTaskMap.parentId").is(102l));
			// find the saved user again.
		 Task savedUser = mongoOperation.findOne(searchUserQuery, Task.class);
			System.out.println("1. find - ParentTaskMap : " + mongoOperation.findAll(SequenceGenerator.class).size());
			
			System.out.println("1. find - ParentTaskMap : " + savedUser.getTaskName());*/
	}
	
}
