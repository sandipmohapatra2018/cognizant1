package com.vijay.api.taskapi.model;


import java.util.Date;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * @author 427629
 *
 */

@XmlRootElement
@Document(collection="tbl_task")
public class Task {

	@Id
	private Long taskId;
	
	@DBRef
	private ParentTask parentTask;
	
	private String taskName;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date startDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date endDate;
	private int priority;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date createdDate;
	
	@JsonbDateFormat(value="yyyy-MM-dd HH:mm:ss")
	private Date modifiedDate;
	
	@Field
	private Boolean isActive =  true;

	/**
	 * @return the taskId
	 */
	public Long getTaskId() {
		return taskId;
	}




	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}




	/**
	 * @return the parentTask
	 */
	public ParentTask getParentTask() {
		return parentTask;
	}




	/**
	 * @param parentTask the parentTask to set
	 */
	public void setParentTask(ParentTask parentTask) {
		this.parentTask = parentTask;
	}




	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}




	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}




	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}




	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}




	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}




	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}




	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}




	/**
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}




	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}




	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}




	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}




	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}




	/**
	 * @return the isActive
	 */
	public Boolean getIsActive() {
		return isActive;
	}




	/**
	 * @param isActive the isActive to set
	 */
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}




	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", parentTaskMap=" + parentTask + ", taskName=" + taskName + ", startDate="
				+ startDate + ", endDate=" + endDate + ", priority=" + priority + ", createdDate=" + createdDate
				+ ", modifiedDate=" + modifiedDate + ", isActive=" + isActive + "]";
	}

}
