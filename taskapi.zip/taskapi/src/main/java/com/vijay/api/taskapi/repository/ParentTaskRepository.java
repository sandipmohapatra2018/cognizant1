package com.vijay.api.taskapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vijay.api.taskapi.model.ParentTask;

public interface ParentTaskRepository extends MongoRepository<ParentTask, String>{

}
