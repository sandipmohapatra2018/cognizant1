package com.vijay.api.taskapi.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.vijay.api.taskapi.model.ParentTask;
import com.vijay.api.taskapi.model.Task;

@Repository
public class ParentTaskRepositoryImpl implements ParentTaskRepository{

	@Autowired
	private MongoOperations mongoOperation;
	
	@Override
	public <S extends ParentTask> List<S> saveAll(Iterable<S> entites) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ParentTask> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ParentTask> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> S insert(S entity) {
			mongoOperation.save(entity);
		return entity;
	}

	@Override
	public <S extends ParentTask> List<S> insert(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<ParentTask> findAll(Pageable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(ParentTask parentTask) {
		mongoOperation.save(parentTask);
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends ParentTask> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean existsById(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<ParentTask> findAllById(Iterable<String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ParentTask> findById(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> S save(S parentTask) {
		System.out.println("Task details :-"+parentTask.toString());
		Query query = new Query();
		query.addCriteria(Criteria.where("parentId").is(parentTask.getParentId()));
		Update update = new Update();
		update.set("parentTaskName", parentTask.getParentTaskName());
		ParentTask retTask = mongoOperation.findAndModify(query, update, ParentTask.class);
		return (S) retTask;
	}

	@Override
	public <S extends ParentTask> long count(Example<S> arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends ParentTask> boolean exists(Example<S> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <S extends ParentTask> Page<S> findAll(Example<S> arg0, Pageable arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends ParentTask> Optional<S> findOne(Example<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
