package com.vijay.api.taskapi.repository;

import com.vijay.api.taskapi.exception.SequenceException;

public interface SequenceDao {

	long getNextSequenceId(String key) throws SequenceException;
}
