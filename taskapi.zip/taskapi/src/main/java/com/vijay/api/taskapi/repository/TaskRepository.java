package com.vijay.api.taskapi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.vijay.api.taskapi.model.Task;

public interface TaskRepository extends MongoRepository<Task, String>{

	Task findById(Long id);

	
}
