package com.vijay.api.taskapi.service;

import java.util.Collection;

import com.vijay.api.taskapi.model.Task;

public interface TaskService {

	Task createTask(Task task);

	Task getTask(Long id);

	Task updateTask(Task task);

	Task removeTask(Long taskId);

	Collection<Task> getTasks();

}
