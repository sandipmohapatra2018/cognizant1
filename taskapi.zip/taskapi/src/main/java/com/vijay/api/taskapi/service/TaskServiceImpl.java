package com.vijay.api.taskapi.service;


import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vijay.api.taskapi.model.ParentTask;
import com.vijay.api.taskapi.model.Task;
import com.vijay.api.taskapi.repository.ParentTaskRepository;
import com.vijay.api.taskapi.repository.SequenceDao;
import com.vijay.api.taskapi.repository.TaskRepository;

@Service
public class TaskServiceImpl implements TaskService{

	private static final String TASK_SEQ_KEY = "tbl_task.taskid";
	private static final String PARENTTASK_SEQ_KEY = "tbl_parenttask.parentid";
	
	@Autowired
	private SequenceDao sequenceDao;
	
	@Autowired
	private TaskRepository taskDao;
	
	@Autowired
	private ParentTaskRepository parentTaskRepo;
	
	
	@Override
	public Task createTask(Task task) {
		Task retTask = null;
		task.setTaskId(sequenceDao.getNextSequenceId(TASK_SEQ_KEY));
		if(task.getParentTask() != null && task.getParentTask().getParentId() == null 
				&& task.getParentTask().getParentTaskName() != null
				&& !task.getParentTask().getParentTaskName().isEmpty()) {
			ParentTask parentTask = new ParentTask();
			parentTask.setParentId(sequenceDao.getNextSequenceId(PARENTTASK_SEQ_KEY));
			parentTask.setParentTaskName(task.getParentTask().getParentTaskName());
			parentTaskRepo.insert(parentTask);
			task.setParentTask(parentTask);
		}
		System.out.println("Task :"+task.toString());
		retTask = taskDao.insert(task);
		
		return retTask;
	}

	@Override
	public Task getTask(Long taskId) {
		Task task = taskDao.findById(taskId);
		return task;
	}

	@Override
	public Task updateTask(Task task) {
		
		if(task.getParentTask() != null && task.getParentTask().getParentId() != null && task.getParentTask().getParentId().longValue() != 0) {
			
			parentTaskRepo.save(task.getParentTask());
		}else if(task.getParentTask() != null && task.getParentTask().getParentId() != null  && task.getParentTask().getParentId().longValue() == 0) {
			ParentTask parentTask = new ParentTask();
			parentTask.setParentId(sequenceDao.getNextSequenceId(PARENTTASK_SEQ_KEY));
			parentTask.setParentTaskName(task.getParentTask().getParentTaskName());
			parentTaskRepo.insert(parentTask);
			task.setParentTask(parentTask);
		}
		Task retTask = taskDao.save(task);
		return retTask;
	}

	@Override
	public Task removeTask(Long taskId) {
		Task task = getTask(taskId);
		if(task != null && task.getParentTask() != null) {
			ParentTask pTask = task.getParentTask();
			pTask.setIsActive(false);
			parentTaskRepo.delete(pTask);
		}
		task.setEndDate(new Date());
		task.setIsActive(false);
		taskDao.delete(task);
		return task;
	}

	@Override
	public Collection<Task> getTasks() {
		return taskDao.findAll();
	}
	
	
	
}
